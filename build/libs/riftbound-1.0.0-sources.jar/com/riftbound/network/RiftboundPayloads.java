package com.riftbound.network;

import com.riftbound.ability.AbilityManager;
import com.riftbound.progression.PlayerRiftData;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class RiftboundPayloads {
    public static void register() {
        PayloadTypeRegistry.playS2C().register(SyncProgressionPayload.TYPE, SyncProgressionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UseAbilityPayload.TYPE, UseAbilityPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(UseAbilityPayload.TYPE, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                AbilityManager.useAbility(player, payload.abilityId());
            });
        });
    }

    public static void syncToClient(class_3222 player, PlayerRiftData data) {
        ServerPlayNetworking.send(player, new SyncProgressionPayload(
            data.getUnlockedTier() > 0,
            data.getUnlockedTier(),
            data.getDashCooldown(),
            data.getPulseCooldown(),
            data.getShieldCooldown(),
            data.getShieldActiveTicks()
        ));
    }

    public record SyncProgressionPayload(boolean unlocked, int unlockedTier, int dashCooldown, int pulseCooldown, int shieldCooldown, int shieldActiveTicks) implements class_8710 {
        public static final class_8710.class_9154<SyncProgressionPayload> TYPE = 
            new class_8710.class_9154<>(class_2960.method_60655("riftbound", "sync_progression"));
        public static final class_9139<class_9129, SyncProgressionPayload> CODEC = 
            class_9139.method_56437((buf, value) -> {
                buf.method_52964(value.unlocked);
                buf.method_53002(value.unlockedTier);
                buf.method_53002(value.dashCooldown);
                buf.method_53002(value.pulseCooldown);
                buf.method_53002(value.shieldCooldown);
                buf.method_53002(value.shieldActiveTicks);
            }, buf -> new SyncProgressionPayload(
                buf.readBoolean(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt(), buf.readInt()
            ));

        @Override
        public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }

    public record UseAbilityPayload(int abilityId) implements class_8710 {
        public static final class_8710.class_9154<UseAbilityPayload> TYPE = 
            new class_8710.class_9154<>(class_2960.method_60655("riftbound", "use_ability"));
        public static final class_9139<class_9129, UseAbilityPayload> CODEC = 
            class_9139.method_56437((buf, value) -> buf.method_53002(value.abilityId), buf -> new UseAbilityPayload(buf.readInt()));

        @Override
        public class_9154<? extends class_8710> method_56479() { return TYPE; }
    }
}