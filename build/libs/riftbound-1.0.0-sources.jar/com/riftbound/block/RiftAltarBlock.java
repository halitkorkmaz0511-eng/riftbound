package com.riftbound.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_5558;

public class RiftAltarBlock extends class_2237 {
    // 1.21.4 icin gerekli minimum codec tanimi
    public static final MapCodec<RiftAltarBlock> CODEC = method_54094(RiftAltarBlock::new);

    public RiftAltarBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (!level.field_9236 && level.method_8321(pos) instanceof RiftAltarBlockEntity be) {
            boolean activated = be.activate(player);
            if (activated) return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new RiftAltarBlockEntity(pos, state);
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state, class_2591<T> type) {
        if (level.field_9236) return null;
        return method_31618(type, ModBlockEntities.RIFT_ALTAR_BE, RiftAltarBlockEntity::tick);
    }
}