package com.riftbound.block;

import com.riftbound.ability.AbilityManager;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public class RiftAltarBlockEntity extends class_2586 {
    private int state = 0; // 0=IDLE, 1=WAVE_ACTIVE, 2=COOLDOWN, 3=BOSS_ACTIVE
    private int cooldownTicks = 0;
    private int checkTicks = 0;
    private static final String MOB_TAG = "rift_shrine_mob";
    private static final String BOSS_TAG = "rift_sentinel_boss";

    public RiftAltarBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.RIFT_ALTAR_BE, pos, state);
    }

    public boolean activate(class_1657 player) {
        if (state != 0) {
            if (state == 2) player.method_7353(class_2561.method_43470("§cAltarin enerjisi tukenmis. Daha sonra tekrar gel."), true);
            else if (state == 3) player.method_7353(class_2561.method_43470("§4Rituel zaten basladi! Hayatta kalmaya calis!"), true);
            return false;
        }

        // Oyuncunun elinde Rift Core olup olmadigini kontrol et
        class_1799 mainHand = player.method_5998(class_1268.field_5808);
        class_1799 offHand = player.method_5998(class_1268.field_5810);
        boolean hasCoreInMain = mainHand.method_7909() == com.riftbound.item.ModItems.RIFT_CORE;
        boolean hasCoreInOff = offHand.method_7909() == com.riftbound.item.ModItems.RIFT_CORE;

        if (hasCoreInMain || hasCoreInOff) {
            // BOSS RİTÜELİNİ BAŞLAT
            if (hasCoreInMain) mainHand.method_7934(1);
            else offHand.method_7934(1);

            state = 3; // BOSS_ACTIVE State
            method_5431();

            if (field_11863 instanceof class_3218 sLevel) {
                sLevel.method_8396(null, method_11016(), class_3417.field_14792, class_3419.field_15245, 1.0f, 0.5f);
                sLevel.method_8396(null, method_11016(), class_3417.field_14865, class_3419.field_15245, 1.0f, 1.0f);
                
                // Dev mor ve camgobegi isin / patlama efekti
                sLevel.method_65096(AbilityManager.RIFT_PURPLE, method_11016().method_10263() + 0.5, method_11016().method_10264() + 3.0, method_11016().method_10260() + 0.5, 300, 1.0, 5.0, 1.0, 0.5);
                sLevel.method_65096(AbilityManager.RIFT_CYAN, method_11016().method_10263() + 0.5, method_11016().method_10264() + 3.0, method_11016().method_10260() + 0.5, 100, 2.0, 2.0, 2.0, 0.2);

                player.method_7353(class_2561.method_43470("§4§lBoyut yirtiliyor! RIFT SENTINEL UYANDI!"), true);
                
                // Boss'u Cagir (1.21.4 Optional duzeltmesi)
                Optional<net.minecraft.class_6880.class_6883<class_1299<?>>> optionalType = class_7923.field_41177.method_10223(net.minecraft.class_2960.method_60655("riftbound", "rift_sentinel"));
                if (optionalType.isPresent()) {
                    class_1299<?> sentinelType = optionalType.get().comp_349();
                    net.minecraft.class_1297 boss = sentinelType.method_5883(sLevel, class_3730.field_16469);
                    if (boss instanceof class_1309 livingBoss) {
                        livingBoss.method_5814(method_11016().method_10263() + 0.5, method_11016().method_10264() + 5.0, method_11016().method_10260() + 0.5);
                        livingBoss.method_5780(BOSS_TAG);
                        sLevel.method_8649(livingBoss);
                    }
                }
            }
            return true;
        } else {
            // NORMAL WAVE BAŞLAT (Eski sistem)
            state = 1;
            checkTicks = 0;
            method_5431();
            if (field_11863 instanceof class_3218 sLevel) {
                sLevel.method_8396(null, method_11016(), class_3417.field_14981, class_3419.field_15245, 1.0f, 0.8f);
                sLevel.method_65096(AbilityManager.RIFT_PURPLE, method_11016().method_10263() + 0.5, method_11016().method_10264() + 1.5, method_11016().method_10260() + 0.5, 100, 1.0, 1.0, 1.0, 0.1);
                spawnWave(sLevel);
                player.method_7353(class_2561.method_43470("§dBoyut yirtigi acildi! Gelenleri yok et!"), true);
            }
            return true;
        }
    }

    private void spawnWave(class_3218 level) {
        class_2338 p = method_11016();
        for(int i = 0; i < 4; i++) {
            class_1560 mob = class_1299.field_6091.method_5883(level, class_3730.field_16469);
            if(mob != null) {
                mob.method_5814(p.method_10263() + (level.field_9229.method_43058() * 8 - 4), p.method_10264() + 1, p.method_10260() + (level.field_9229.method_43058() * 8 - 4));
                mob.method_5780(MOB_TAG);
                mob.method_5665(class_2561.method_43470("§5Rift Walker"));
                mob.method_5880(true);
                level.method_8649(mob);
            }
        }
    }

    public static void tick(class_1937 level, class_2338 pos, class_2680 state, RiftAltarBlockEntity be) {
        if (level.field_9236) return;
        
        if (be.state == 1) { // Wave Takibi
            be.checkTicks++;
            if (be.checkTicks >= 40) { 
                be.checkTicks = 0;
                class_238 area = new class_238(pos).method_1014(24);
                List<class_1309> mobs = level.method_8390(class_1309.class, area, e -> e.method_5752().contains(MOB_TAG));
                
                if (mobs.isEmpty()) {
                    be.state = 2; // Savas bitti, cooldown
                    be.cooldownTicks = 6000;
                    be.method_5431();
                    level.method_8396(null, pos, class_3417.field_15195, class_3419.field_15245, 1.0f, 1.0f);
                    if (level instanceof class_3218 sLevel) {
                        sLevel.method_65096(AbilityManager.RIFT_CYAN, pos.method_10263() + 0.5, pos.method_10264() + 1.5, pos.method_10260() + 0.5, 200, 0.5, 1.5, 0.5, 0.1);
                    }
                    class_1542 reward = new class_1542(level, pos.method_10263() + 0.5, pos.method_10264() + 1.5, pos.method_10260() + 0.5, new class_1799(com.riftbound.item.ModItems.RIFT_CORE));
                    level.method_8649(reward);
                }
            }
        } else if (be.state == 3) { // Boss Takibi
            be.checkTicks++;
            if (be.checkTicks >= 40) {
                be.checkTicks = 0;
                class_238 area = new class_238(pos).method_1014(48); // Boss arenasi daha genis taranir
                List<class_1309> bosses = level.method_8390(class_1309.class, area, e -> e.method_5752().contains(BOSS_TAG));
                
                if (bosses.isEmpty()) {
                    be.state = 2; // Boss bitti, Altar dinlenmeye (cooldown) gecer
                    be.cooldownTicks = 12000; // Boss savasi sonrasi 10 dakika cooldown
                    be.method_5431();
                    level.method_8396(null, pos, class_3417.field_15195, class_3419.field_15245, 1.0f, 1.0f);
                    if (level instanceof class_3218 sLevel) {
                        sLevel.method_65096(AbilityManager.RIFT_CYAN, pos.method_10263() + 0.5, pos.method_10264() + 1.5, pos.method_10260() + 0.5, 500, 2.0, 2.0, 2.0, 0.2);
                    }
                }
            }
        } else if (be.state == 2) { // Cooldown
            be.cooldownTicks--;
            if (be.cooldownTicks <= 0) {
                be.state = 0;
                be.method_5431();
            }
        }
    }

    @Override
    protected void method_11007(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11007(tag, registries);
        tag.method_10569("RiftState", state);
        tag.method_10569("RiftCooldown", cooldownTicks);
    }

    @Override
    protected void method_11014(class_2487 tag, class_7225.class_7874 registries) {
        super.method_11014(tag, registries);
        state = tag.method_10550("RiftState");
        cooldownTicks = tag.method_10550("RiftCooldown");
    }
}