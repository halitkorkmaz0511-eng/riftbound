package com.riftbound.block;

import com.riftbound.RiftboundMod;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModBlocks {
    // 1.21.4 uyumlu factory tabanlı blok kaydı
    public static final class_2248 RIFT_ALTAR = registerBlock("rift_altar", 
        props -> new RiftAltarBlock(props.method_9629(5.0f, 1200.0f).method_9631(s -> 12).method_29292())
    );

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> factory) {
        class_2960 id = class_2960.method_60655("riftbound", name);
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, id);
        
        // KRİTİK DÜZELTME: Block id not set hatasını önlemek için setId(blockKey) uygulanıyor
        class_4970.class_2251 props = class_4970.class_2251.method_9637().method_63500(blockKey);
        class_2248 registered = class_2378.method_39197(class_7923.field_41175, blockKey, factory.apply(props));
        
        class_2378.method_39197(class_7923.field_41178, itemKey, new class_1747(registered, new class_1792.class_1793().method_63686(itemKey)));
        return registered;
    }

    public static void register() {
        RiftboundMod.LOGGER.info("Registering Riftbound Blocks...");
    }
}