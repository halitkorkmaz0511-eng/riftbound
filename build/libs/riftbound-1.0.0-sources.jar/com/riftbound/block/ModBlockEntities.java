package com.riftbound.block;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {
    public static class_2591<RiftAltarBlockEntity> RIFT_ALTAR_BE;

    public static void register() {
        RIFT_ALTAR_BE = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655("riftbound", "rift_altar"),
            FabricBlockEntityTypeBuilder.create(RiftAltarBlockEntity::new, ModBlocks.RIFT_ALTAR).build()
        );
    }
}