package com.riftbound.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RiftGuideScreen extends class_437 {
    private int currentPage = 0;
    private final int totalPages = 3;

    public RiftGuideScreen() {
        super(class_2561.method_43470("Riftbound Rehberi"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // Geri Butonu
        this.method_37063(class_4185.method_46430(class_2561.method_43470("< Geri"), button -> {
            if (currentPage > 0) {
                currentPage--;
                this.method_37067();
                this.method_25426();
            }
        }).method_46434(centerX - 140, centerY + 85, 60, 20).method_46431());

        // Ileri Butonu
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Ileri >"), button -> {
            if (currentPage < totalPages - 1) {
                currentPage++;
                this.method_37067();
                this.method_25426();
            }
        }).method_46434(centerX + 80, centerY + 85, 60, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        // Yari seffaf arka plan
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xB3000000);
        
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;
        
        // Ana Cerceve (Koyu Mor)
        graphics.method_25294(centerX - 150, centerY - 110, centerX + 150, centerY + 110, 0xFF12081C);
        
        // Cerceve Kenarliklari (Camgobegi)
        graphics.method_25294(centerX - 151, centerY - 111, centerX + 151, centerY - 110, 0xFF00DCFF);
        graphics.method_25294(centerX - 151, centerY + 110, centerX + 151, centerY + 111, 0xFF00DCFF);
        graphics.method_25294(centerX - 151, centerY - 111, centerX - 150, centerY + 111, 0xFF00DCFF);
        graphics.method_25294(centerX + 150, centerY - 111, centerX + 151, centerY + 111, 0xFF00DCFF);

        // Butonlarin cizilmesi
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        graphics.method_25300(this.field_22793, "§d§l=== RIFTBOUND REHBERI (" + (currentPage + 1) + "/" + totalPages + ") ===", centerX, centerY - 95, 0xFFFFFF);

        if (currentPage == 0) {
            graphics.method_25303(this.field_22793, "§b[ 1. Boyut Monoliti ]", centerX - 135, centerY - 70, 0xFFFFFF);
            graphics.method_25303(this.field_22793, "§7Dunyada tapinagi bul veya komutla insa et.", centerX - 135, centerY - 55, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7Merkezdeki Altar'a sag tiklayip yaratik", centerX - 135, centerY - 45, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7dalgasini (Rift Walker) temizle.", centerX - 135, centerY - 35, 0xAAAAAA);
            
            graphics.method_25303(this.field_22793, "§b[ 2. Boyut Cekirdegi (Rift Core) ]", centerX - 135, centerY - 10, 0xFFFFFF);
            graphics.method_25303(this.field_22793, "§7Sunagi savundugunda bu cekirdek duser.", centerX - 135, centerY + 5, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7Eline alip sag tiklayarak kendi gucunu", centerX - 135, centerY + 15, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7artir (Atilma, Sok Dalgasi, Gecici Kalkan).", centerX - 135, centerY + 25, 0xAAAAAA);
        } else if (currentPage == 1) {
            graphics.method_25303(this.field_22793, "§b[ 3. Ozel Silahlar ]", centerX - 135, centerY - 70, 0xFFFFFF);
            graphics.method_25303(this.field_22793, "§cBoyut Kilici:§7 Sag tikla baktigin yere isinlan.", centerX - 135, centerY - 55, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§cBoyut Tirpani:§7 Vuruslar can calar ve alan", centerX - 135, centerY - 45, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7hasari verir. Sag tikla girdap yaratip cek.", centerX - 135, centerY - 35, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§cBoyut Asasi:§7 Sag tikla delici lazer atesle.", centerX - 135, centerY - 25, 0xAAAAAA);
            
            graphics.method_25303(this.field_22793, "§b[ 4. Rift Zirh Seti ]", centerX - 135, centerY, 0xFFFFFF);
            graphics.method_25303(this.field_22793, "§7Ozel zirhlarin 4 parcasini da ayni anda", centerX - 135, centerY + 15, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7giydiginde set bonusu aktiflesir:", centerX - 135, centerY + 25, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§eHiz, Direnc ve Gece Gorusu§7 kazanirsin.", centerX - 135, centerY + 35, 0xAAAAAA);
        } else if (currentPage == 2) {
            graphics.method_25303(this.field_22793, "§b[ 5. Rift Sentinel (Nihai Boss) ]", centerX - 135, centerY - 70, 0xFFFFFF);
            graphics.method_25303(this.field_22793, "§7Silah ve zirhlarini urettikten sonra,", centerX - 135, centerY - 55, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7elinde §dBoyut Cekirdegi§7 varken", centerX - 135, centerY - 45, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7Altar'a sag tiklayarak asil ritueli baslat.", centerX - 135, centerY - 35, 0xAAAAAA);
            
            graphics.method_25303(this.field_22793, "§7Bu eylem elindeki cekirdegi tuketir", centerX - 135, centerY - 15, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§7ve gokyuzunden §cRift Sentinel§7'i indirir.", centerX - 135, centerY - 5, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§8(Not: Rituel sistemini test ettikten", centerX - 135, centerY + 15, 0xAAAAAA);
            graphics.method_25303(this.field_22793, "§8hemen sonra uretime [crafting] gececegiz)", centerX - 135, centerY + 25, 0xAAAAAA);
        }
    }

    @Override
    public boolean method_25421() {
        return false; // Ekran acikken oyun arkada akmaya devam etsin
    }
}