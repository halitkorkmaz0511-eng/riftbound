package com.riftbound.client.render;

import com.riftbound.RiftboundMod;
import com.riftbound.entity.boss.RiftSentinelEntity;
import net.minecraft.class_10042;
import net.minecraft.class_2960;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_7094;
import net.minecraft.class_927;

public class RiftSentinelRenderer extends class_927<RiftSentinelEntity, RiftSentinelRenderer.SentinelRenderState, RiftSentinelModel> {
    public static final class_5601 LAYER_LOCATION =
            new class_5601(RiftboundMod.id("rift_sentinel"), "main");

    private static final class_2960 TEXTURE =
            class_2960.method_60656("textures/entity/enderman/enderman.png");

    public RiftSentinelRenderer(class_5617.class_5618 context) {
        super(context, new RiftSentinelModel(context.method_32167(LAYER_LOCATION)), 0.85F);
    }

    @Override
    public SentinelRenderState method_55269() {
        return new SentinelRenderState();
    }

    @Override
    public void extractRenderState(RiftSentinelEntity entity, SentinelRenderState state, float partialTick) {
        super.method_62355(entity, state, partialTick);
        state.enraged = entity.isEnraged();
        state.idleAnimationState.method_61401(entity.idleAnimationState);
        state.strikeAnimationState.method_61401(entity.strikeAnimationState);
        state.voidWaveAnimationState.method_61401(entity.voidWaveAnimationState);
        state.deathAnimationState.method_61401(entity.deathAnimationState);
    }

    @Override
    public class_2960 getTextureLocation(SentinelRenderState state) {
        return TEXTURE;
    }

    public static class SentinelRenderState extends class_10042 {
        public boolean enraged;
        public final class_7094 idleAnimationState = new class_7094();
        public final class_7094 strikeAnimationState = new class_7094();
        public final class_7094 voidWaveAnimationState = new class_7094();
        public final class_7094 deathAnimationState = new class_7094();
    }
}
