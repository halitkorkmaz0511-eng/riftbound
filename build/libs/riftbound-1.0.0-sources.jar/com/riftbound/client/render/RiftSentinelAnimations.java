package com.riftbound.client.render;

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;

public class RiftSentinelAnimations {
    public static final class_7184 IDLE = class_7184.class_7185.method_41818(2.0f).method_41817()
            .method_41820("core", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0f, class_7187.method_41823(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(1.0f, class_7187.method_41823(0.0f, 3.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(2.0f, class_7187.method_41823(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885)))
            .method_41820("core", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37884),
                    new class_7186(2.0f, class_7187.method_41829(0.0f, 180.0f, 0.0f), class_7179.class_7181.field_37884)))
            .method_41821();

    public static final class_7184 RIFT_STRIKE = class_7184.class_7185.method_41818(1.6f)
            .method_41820("right_arm", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(0.65f, class_7187.method_41829(-145.0f, -20.0f, 15.0f), class_7179.class_7181.field_37885),
                    new class_7186(0.85f, class_7187.method_41829(55.0f, 15.0f, -10.0f), class_7179.class_7181.field_37884),
                    new class_7186(1.25f, class_7187.method_41829(45.0f, 10.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(1.6f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885)))
            .method_41820("left_arm", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(0.65f, class_7187.method_41829(-130.0f, 20.0f, -15.0f), class_7179.class_7181.field_37885),
                    new class_7186(0.85f, class_7187.method_41829(50.0f, -15.0f, 10.0f), class_7179.class_7181.field_37884),
                    new class_7186(1.6f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885)))
            .method_41821();

    public static final class_7184 VOID_WAVE = class_7184.class_7185.method_41818(1.6f)
            .method_41820("right_arm", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(1.1f, class_7187.method_41829(-90.0f, 0.0f, 75.0f), class_7179.class_7181.field_37885),
                    new class_7186(1.4f, class_7187.method_41829(20.0f, 0.0f, -30.0f), class_7179.class_7181.field_37884),
                    new class_7186(1.6f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885)))
            .method_41820("left_arm", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(1.1f, class_7187.method_41829(-90.0f, 0.0f, -75.0f), class_7179.class_7181.field_37885),
                    new class_7186(1.4f, class_7187.method_41829(20.0f, 0.0f, 30.0f), class_7179.class_7181.field_37884),
                    new class_7186(1.6f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885)))
            .method_41821();

    public static final class_7184 DEATH = class_7184.class_7185.method_41818(3.0f)
            .method_41820("body", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0f, class_7187.method_41823(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(2.0f, class_7187.method_41823(0.0f, 10.0f, 0.0f), class_7179.class_7181.field_37885),
                    new class_7186(3.0f, class_7187.method_41823(0.0f, -12.0f, 0.0f), class_7179.class_7181.field_37884)))
            .method_41820("body", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0f, class_7187.method_41829(0.0f, 0.0f, 0.0f), class_7179.class_7181.field_37884),
                    new class_7186(3.0f, class_7187.method_41829(25.0f, 540.0f, 0.0f), class_7179.class_7181.field_37884)))
            .method_41821();
}
