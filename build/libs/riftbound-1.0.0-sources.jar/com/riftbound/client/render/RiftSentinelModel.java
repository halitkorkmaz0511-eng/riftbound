package com.riftbound.client.render;

import net.minecraft.class_3532;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;

public class RiftSentinelModel extends class_583<RiftSentinelRenderer.SentinelRenderState> {
    private final class_630 body;
    private final class_630 head;
    private final class_630 core;
    private final class_630 rightArm;
    private final class_630 leftArm;

    public RiftSentinelModel(class_630 root) {
        super(root);
        this.body = root.method_32086("body");
        this.head = this.body.method_32086("head");
        this.core = this.body.method_32086("core");
        this.rightArm = this.body.method_32086("right_arm");
        this.leftArm = this.body.method_32086("left_arm");
    }

    public static class_5607 createBodyLayer() {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();

        class_5610 body = root.method_32117("body",
                class_5606.method_32108()
                        .method_32101(0, 16).method_32098(-7.0F, -24.0F, -4.0F, 14.0F, 14.0F, 8.0F, new class_5605(0.0F))
                        .method_32101(0, 38).method_32098(-4.5F, -10.0F, -2.5F, 9.0F, 10.0F, 5.0F, new class_5605(0.0F)),
                class_5603.method_32090(0.0F, 24.0F, 0.0F));

        body.method_32117("head",
                class_5606.method_32108()
                        .method_32101(0, 0).method_32097(-4.5F, -9.0F, -4.5F, 9.0F, 9.0F, 9.0F)
                        .method_32101(36, 0).method_32097(-7.5F, -13.0F, -1.0F, 3.0F, 8.0F, 3.0F)
                        .method_32101(36, 0).method_32097(4.5F, -13.0F, -1.0F, 3.0F, 8.0F, 3.0F),
                class_5603.method_32090(0.0F, -25.0F, 0.0F));

        body.method_32117("core",
                class_5606.method_32108()
                        .method_32101(36, 16).method_32098(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 6.0F, new class_5605(0.25F)),
                class_5603.method_32090(0.0F, -17.0F, 0.0F));

        body.method_32117("right_arm",
                class_5606.method_32108()
                        .method_32101(44, 28).method_32097(-5.0F, -2.0F, -3.0F, 5.0F, 22.0F, 6.0F),
                class_5603.method_32090(-8.0F, -22.0F, 0.0F));

        body.method_32117("left_arm",
                class_5606.method_32108()
                        .method_32101(44, 28).method_32096().method_32097(0.0F, -2.0F, -3.0F, 5.0F, 22.0F, 6.0F),
                class_5603.method_32090(8.0F, -22.0F, 0.0F));

        return class_5607.method_32110(mesh, 64, 64);
    }

    @Override
    public void setupAnim(RiftSentinelRenderer.SentinelRenderState state) {
        super.method_2819(state);
        this.head.field_3675 = state.field_53447 * ((float) Math.PI / 180F);
        this.head.field_3654 = state.field_53448 * ((float) Math.PI / 180F);

        this.rightArm.field_3654 += class_3532.method_15362(state.field_53450 * 0.6662F) * 0.8F * state.field_53451;
        this.leftArm.field_3654 += class_3532.method_15362(state.field_53450 * 0.6662F + (float) Math.PI) * 0.8F * state.field_53451;

        this.method_62099(state.idleAnimationState, RiftSentinelAnimations.IDLE, state.field_53328, 1.0F);
        this.method_62099(state.strikeAnimationState, RiftSentinelAnimations.RIFT_STRIKE, state.field_53328, 1.0F);
        this.method_62099(state.voidWaveAnimationState, RiftSentinelAnimations.VOID_WAVE, state.field_53328, 1.0F);
        this.method_62099(state.deathAnimationState, RiftSentinelAnimations.DEATH, state.field_53328, 1.0F);
    }
}
