package com.riftbound.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class RiftboundClient implements ClientModInitializer {
    private static class_304 guideKeyBinding;

    @Override
    public void onInitializeClient() {
        // 'Z' tusunu kaydet
        guideKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "Riftbound Rehberi Ac/Kapat",
            GLFW.GLFW_KEY_Z,
            "Riftbound Mod"
        ));

        // Tusa basildiginda ekrani ac
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (guideKeyBinding.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new RiftGuideScreen());
                }
            }
        });
    }
}