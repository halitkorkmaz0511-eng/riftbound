package com.riftbound.world;

import com.riftbound.block.ModBlocks;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

public class RiftMonolithGenerator {
    public static void buildMonolith(class_3218 level, class_2338 center) {
        // 7x7 Taban (Obsidyen ve Polished Blackstone)
        for (int x = -3; x <= 3; x++) {
            for (int z = -3; z <= 3; z++) {
                if (Math.abs(x) == 3 || Math.abs(z) == 3) {
                    level.method_8501(center.method_10069(x, -1, z), class_2246.field_23874.method_9564());
                } else {
                    level.method_8501(center.method_10069(x, -1, z), class_2246.field_10540.method_9564());
                }
            }
        }
        
        // 4 Kose Kirik Sutunlari (Crying Obsidian & Cyan Glass)
        int[][] corners = {{-3,-3}, {3,-3}, {-3,3}, {3,3}};
        for (int[] c : corners) {
            level.method_8501(center.method_10069(c[0], 0, c[1]), class_2246.field_22423.method_9564());
            level.method_8501(center.method_10069(c[0], 1, c[1]), class_2246.field_10248.method_9564());
            level.method_8501(center.method_10069(c[0], 2, c[1]), class_2246.field_10455.method_9564());
        }

        // Giris Merdiveni
        level.method_8501(center.method_10069(0, -1, -4), class_2246.field_23878.method_9564());
        level.method_8501(center.method_10069(-1, -1, -4), class_2246.field_23878.method_9564());
        level.method_8501(center.method_10069(1, -1, -4), class_2246.field_23878.method_9564());

        // Merkez Sunagi
        level.method_8501(center.method_10069(0, 0, 0), class_2246.field_23874.method_9564());
        level.method_8501(center.method_10069(0, 1, 0), ModBlocks.RIFT_ALTAR.method_9564());
    }
}