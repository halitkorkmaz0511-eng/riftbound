package com.riftbound.horror;
import com.riftbound.horror.event.RealityCorruptionSequence;
import com.riftbound.horror.event.FalseMorningEvent;
import com.riftbound.horror.event.TheDoppelgangerEvent;
import com.riftbound.horror.event.ChronophobiaEvent;
import com.riftbound.horror.event.SpatialDistortionEvent;
import com.riftbound.horror.event.HorrorEvent;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Map;

public class HorrorDirector {
    private static int tickCounter = 0;

    public static void init() {
        HorrorEventRegistry.register(new RealityCorruptionSequence());
        HorrorEventRegistry.register(new FalseMorningEvent());
        HorrorEventRegistry.register(new TheDoppelgangerEvent());
        HorrorEventRegistry.register(new ChronophobiaEvent());
        HorrorEventRegistry.register(new SpatialDistortionEvent());
        ServerTickEvents.END_SERVER_TICK.register(HorrorDirector::onServerTick);
        HorrorCommand.register();
    }

    private static void onServerTick(MinecraftServer server) {
        tickCounter++;
        class_3218 overworld = server.method_3847(class_1937.field_25179);
        if (overworld == null) return;

        HorrorState state = overworld.method_17983().method_17924(HorrorState.factory(), "riftbound_horror_state");
        long currentTick = overworld.method_8510();

        for (class_3218 sLevel : server.method_3738()) {
            for (class_3222 player : sLevel.method_18456()) {
                if (player.method_7325() || player.method_7337()) continue;
                UUID uuid = player.method_5667();

                if (state.activeSequenceId.containsKey(uuid)) {
                    String activeSeqId = state.activeSequenceId.get(uuid);
                    HorrorEvent activeEvent = HorrorEventRegistry.getEvent(activeSeqId);
                    if (activeEvent != null) {
                        long startTick = state.sequenceStartTick.getOrDefault(uuid, currentTick);
                        if (activeEvent.tick(sLevel, player, state, currentTick - startTick) || player.method_29504()) {
                            activeEvent.cleanup(sLevel, player);
                            state.endSequence(uuid, currentTick);
                        }
                    } else state.endSequence(uuid, currentTick);
                    continue;
                }

                if (tickCounter % 20 == 0) state.analyzePlayer(player);
                if (tickCounter % 40 != 0) continue; 

                long lastGlobal = state.lastGlobalEventTick.getOrDefault(uuid, 0L);
                if (currentTick - lastGlobal < 6000) continue;

                float stress = state.undergroundStress.getOrDefault(uuid, 0f);
                int chance = 1000;
                if (stress > 50) chance -= 300;
                if (stress > 75) chance -= 400; 

                if (sLevel.field_9229.method_43048(Math.max(50, chance)) == 0) {
                    List<HorrorEvent> eligible = new ArrayList<>();
                    int totalWeight = 0;

                    for (HorrorEvent ev : HorrorEventRegistry.getAll()) {
                        if (ev.canTrigger(sLevel, player)) {
                            int dynamicWeight = ev.getWeight();

                            Map<String, Long> lastSeenMap = state.eventLastSeen.get(uuid);
                            if (lastSeenMap != null && lastSeenMap.containsKey(ev.getId())) {
                                long timeSinceLast = currentTick - lastSeenMap.get(ev.getId());
                                if (timeSinceLast < 18000) continue;
                                if (timeSinceLast > 48000) dynamicWeight *= 2;
                            }

                            if (stress > 75 && ev.getId().equals("riftbound:false_morning")) dynamicWeight += 100;

                            eligible.add(ev);
                            totalWeight += dynamicWeight;
                        }
                    }

                    if (!eligible.isEmpty()) {
                        int r = sLevel.field_9229.method_43048(totalWeight);
                        int sum = 0;
                        for (HorrorEvent ev : eligible) {
                            Map<String, Long> lastSeenMap = state.eventLastSeen.get(uuid);
                            int dynamicWeight = ev.getWeight();
                            if (lastSeenMap != null && lastSeenMap.containsKey(ev.getId())) {
                                if (currentTick - lastSeenMap.get(ev.getId()) > 48000) dynamicWeight *= 2;
                            }
                            if (stress > 75 && ev.getId().equals("riftbound:false_morning")) dynamicWeight += 100;

                            sum += dynamicWeight;
                            if (r < sum) {
                                if (ev.getId().equals("riftbound:reality_corruption")) {
                                    if (stress > 75) state.forcedVariation.put(uuid, sLevel.field_9229.method_43056() ? 2 : 3);
                                    else if (stress > 50) state.forcedVariation.put(uuid, 1);
                                }
                                state.startSequence(uuid, ev.getId(), currentTick);
                                break;
                            }
                        }
                    }
                }
            }
        }
    }
}