package com.riftbound.horror;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import net.minecraft.class_7225;

public class HorrorState extends class_18 {
    public Map<UUID, Long> lastGlobalEventTick = new HashMap<>();
    public Map<UUID, String> activeSequenceId = new HashMap<>();
    public Map<UUID, Long> sequenceStartTick = new HashMap<>();
    public Map<UUID, Integer> forcedVariation = new HashMap<>();
    
    // FEAR HISTORY (Korku Geçmişi)
    public Map<UUID, Map<String, Integer>> eventPlayCounts = new HashMap<>();
    public Map<UUID, Map<String, Long>> eventLastSeen = new HashMap<>();
    
    // UNDERGROUND STRESS (0-100 Stres Sistemi)
    public Map<UUID, Float> undergroundStress = new HashMap<>();

    public HorrorState() {}

    public static class_18.class_8645<HorrorState> factory() { return new class_18.class_8645<>(HorrorState::new, HorrorState::load, null); }
    public static HorrorState load(class_2487 tag, class_7225.class_7874 provider) { return new HorrorState(); }
    @Override public class_2487 method_75(class_2487 tag, class_7225.class_7874 provider) { return tag; }

    public void startSequence(UUID uuid, String eventId, long currentTick) {
        activeSequenceId.put(uuid, eventId);
        sequenceStartTick.put(uuid, currentTick);
        lastGlobalEventTick.put(uuid, currentTick);
        
        // Fear History Güncellemesi
        eventPlayCounts.computeIfAbsent(uuid, k -> new HashMap<>()).merge(eventId, 1, Integer::sum);
        eventLastSeen.computeIfAbsent(uuid, k -> new HashMap<>()).put(eventId, currentTick);
        method_80();
    }

    public void endSequence(UUID uuid, long currentTick) {
        activeSequenceId.remove(uuid);
        sequenceStartTick.remove(uuid);
        forcedVariation.remove(uuid);
        method_80();
    }
    
    public void analyzePlayer(class_3222 player) {
        UUID uuid = player.method_5667();
        
        // STRES HESAPLAMA MOTORU (Her saniye çalışır)
        float currentStress = undergroundStress.getOrDefault(uuid, 0f);
        
        if (player.method_23318() < 50) {
            float stressGain = 0.2f; // Temel artış
            
            // Işık seviyesi düşükse stres çok daha hızlı artar
            int light = player.method_51469().method_22339(player.method_24515());
            if (light < 5) stressGain += 0.5f; 
            
            // Derinlik 0'ın altındaysa (Deepslate katmanı) ekstra stres
            if (player.method_23318() < 0) stressGain += 0.3f;
            
            undergroundStress.put(uuid, Math.min(100f, currentStress + stressGain));
        } else {
            // Yüzeye çıkınca stres yavaşça azalır, huzur gelir
            undergroundStress.put(uuid, Math.max(0f, currentStress - 1.0f));
        }
    }
}