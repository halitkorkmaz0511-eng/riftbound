package com.riftbound.horror;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
// EKSİK OLAN KÜTÜPHANELER EKLENDİ
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HorrorCommand {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            registerCommand(dispatcher);
        });
    }

    private static void registerCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("riftbound_test")
            .requires(source -> source.method_9259(2))
            
            // ALT KOMUT: stop
            .then(class_2170.method_9247("stop")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    HorrorState state = player.method_51469().method_17983().method_17924(HorrorState.factory(), "riftbound_horror_state");
                    state.endSequence(player.method_5667(), player.method_51469().method_8510());
                    player.method_6012();
                    context.getSource().method_9226(() -> class_2561.method_43470("Tum korku sekanslari durduruldu."), false);
                    return 1;
                })
            )

            // ALT KOMUT: var
            .then(class_2170.method_9247("var")
                .then(class_2170.method_9244("variation", IntegerArgumentType.integer(0, 3))
                    .executes(context -> {
                        class_3222 player = context.getSource().method_9207();
                        int var = IntegerArgumentType.getInteger(context, "variation");
                        
                        HorrorState state = player.method_51469().method_17983().method_17924(HorrorState.factory(), "riftbound_horror_state");
                        state.forcedVariation.put(player.method_5667(), var);
                        state.startSequence(player.method_5667(), "riftbound:reality_corruption", player.method_51469().method_8510());
                        
                        context.getSource().method_9226(() -> class_2561.method_43470("Reality Corruption (Var: " + var + ") baslatildi."), false);
                        return 1;
                    })
                )
            )
            
            // ALT KOMUT: debug
            .then(class_2170.method_9247("debug")
                .executes(context -> {
                    class_3222 player = context.getSource().method_9207();
                    HorrorState state = player.method_51469().method_17983().method_17924(HorrorState.factory(), "riftbound_horror_state");
                    UUID uuid = player.method_5667();
                    float stress = state.undergroundStress.getOrDefault(uuid, 0f);
                    
                    context.getSource().method_9226(() -> class_2561.method_43470("§6--- RIFTBOUND DIRECTOR DEBUG ---"), false);
                    context.getSource().method_9226(() -> class_2561.method_43470("§eUnderground Stress: §f" + String.format("%.1f", stress) + "/100"), false);
                    
                    long currentTick = player.method_51469().method_8510();
                    long lastGlobal = state.lastGlobalEventTick.getOrDefault(uuid, 0L);
                    long globalCooldownLeft = Math.max(0, 6000 - (currentTick - lastGlobal));
                    context.getSource().method_9226(() -> class_2561.method_43470("§eGlobal Cooldown: §f" + (globalCooldownLeft/20) + " saniye kaldi."), false);
                    
                    context.getSource().method_9226(() -> class_2561.method_43470("§6--- FEAR HISTORY ---"), false);
                    Map<String, Integer> counts = state.eventPlayCounts.getOrDefault(uuid, new HashMap<>());
                    Map<String, Long> lastSeen = state.eventLastSeen.getOrDefault(uuid, new HashMap<>());
                    
                    if (counts.isEmpty()) {
                        context.getSource().method_9226(() -> class_2561.method_43470("§7Henuz bir olay yasanmadi."), false);
                    } else {
                        for (String evId : counts.keySet()) {
                            long ticksAgo = currentTick - lastSeen.getOrDefault(evId, 0L);
                            int minsAgo = (int) (ticksAgo / 1200);
                            context.getSource().method_9226(() -> class_2561.method_43470("§b" + evId + " §f- Gosterim: " + counts.get(evId) + " | Son Gorulme: " + minsAgo + " dk once"), false);
                        }
                    }
                    return 1;
                })
            )

            // ALT KOMUT: event
            .then(class_2170.method_9247("event")
                .then(class_2170.method_9244("eventId", StringArgumentType.greedyString())
                    .executes(context -> {
                        class_3222 player = context.getSource().method_9207();
                        String eventId = StringArgumentType.getString(context, "eventId");
                        
                        if (HorrorEventRegistry.getEvent(eventId) != null) {
                            HorrorState state = player.method_51469().method_17983().method_17924(HorrorState.factory(), "riftbound_horror_state");
                            state.startSequence(player.method_5667(), eventId, player.method_51469().method_8510());
                            context.getSource().method_9226(() -> class_2561.method_43470(eventId + " baslatildi."), false);
                            return 1;
                        } else {
                            context.getSource().method_9213(class_2561.method_43470("Bilinmeyen event ID: " + eventId));
                            return 0;
                        }
                    })
                )
            )
        );
    }
}