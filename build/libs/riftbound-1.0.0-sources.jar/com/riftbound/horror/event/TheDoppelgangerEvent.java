package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import java.util.Random;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class TheDoppelgangerEvent extends HorrorEvent {
    private final Random random = new Random();

    public TheDoppelgangerEvent() {
        super("riftbound:doppelganger", 1200); // 60 Saniye sürer
    }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }

    @Override
    public void cleanup(class_3218 level, class_3222 player) {}

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        // 1. Saniyede sahte katılım mesajı
        if (age == 20) {
            player.method_64398(class_2561.method_43470("§e[Bilinmeyen] oyuna katildi"));
        }

        // Rastgele aralıklarla arkadan gelen sahte oyuncu sesleri (Yemek, Kazı, Hasar)
        if (age > 100 && age % 50 == 0) {
            if (random.nextFloat() < 0.3f) {
                playFakeSound(level, player, class_3417.field_20614);
            } else if (random.nextFloat() < 0.6f) {
                playFakeSound(level, player, class_3417.field_15026);
            } else if (random.nextFloat() < 0.8f) {
                playFakeSound(level, player, class_3417.field_15115);
            }
        }
        return false;
    }

    private void playFakeSound(class_3218 level, class_3222 player, Object soundObj) {
        class_243 look = player.method_5720();
        class_243 behind = player.method_19538().method_1020(look.method_1021(3.0));
        class_2338 pos = class_2338.method_49637(behind.field_1352, player.method_23318(), behind.field_1350);
        
        net.minecraft.class_3414 sound = null;
        if (soundObj instanceof net.minecraft.class_6880) {
            sound = (net.minecraft.class_3414) ((net.minecraft.class_6880<?>) soundObj).comp_349();
        } else if (soundObj instanceof net.minecraft.class_3414) {
            sound = (net.minecraft.class_3414) soundObj;
        }
        
        if (sound != null) {
            level.method_8396(null, pos, sound, class_3419.field_15248, 1.0f, 1.0f);
        }
    }
}