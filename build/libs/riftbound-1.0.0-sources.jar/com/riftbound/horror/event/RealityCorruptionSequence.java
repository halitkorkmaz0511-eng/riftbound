package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;

public class RealityCorruptionSequence extends HorrorEvent {
    
    private class_1309 spawnedStalker = null;

    public RealityCorruptionSequence() { super("riftbound:reality_corruption", 5); }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }

    @Override
    public void cleanup(class_3218 level, class_3222 player) {
        player.method_6016(class_1294.field_38092);
        player.method_6016(class_1294.field_5919);
        player.method_6016(class_1294.field_5909);
        player.method_6016(class_1294.field_5902);
        player.method_6016(class_1294.field_5916); 
        if (spawnedStalker != null && spawnedStalker.method_5805()) {
            spawnedStalker.method_31472();
            spawnedStalker = null;
        }
    }

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        long seed = state.sequenceStartTick.getOrDefault(player.method_5667(), 0L);
        int variation = state.forcedVariation.containsKey(player.method_5667()) ? state.forcedVariation.get(player.method_5667()) : (int) (Math.abs(seed) % 4);

        if (age == 1) {
            player.method_6092(new class_1293(class_1294.field_38092, 400, 0, false, false));
            playSafeSound(level, player, "ambient.cave", 2.0f, 0.1f);
        }

        if (age > 1 && age < 300 && age % 10 == 0) {
            level.method_65096(class_2398.field_22247, player.method_23317(), player.method_23318() + 3, player.method_23321(), 80, 8.0, 4.0, 8.0, 0.05);
        }

        // ==========================================
        // VARYASYON 0: AGRESİF JUMPSCARE (12 Saniyelik Hızlı Şok)
        // ==========================================
        if (variation == 0) {
            if (age > 20 && age < 160 && age % 20 == 0) playSafeSound(level, player, "entity.warden.heartbeat", 2.0f, 0.5f);
            if (age == 160) {
                spawnedStalker = spawnStalker(level, player, 2.0, 0.0, "rift_aggressor");
                if (spawnedStalker != null) playSafeSound(level, player, "entity.warden.agitated", 3.0f, 0.8f);
            }
            if (age == 170) {
                if (player.method_5805()) {
                    player.method_6092(new class_1293(class_1294.field_5919, 40, 0, false, false));
                    playSafeSound(level, player, "entity.enderman.scream", 3.0f, 0.1f);
                    if (spawnedStalker != null) { spawnedStalker.method_31472(); spawnedStalker = null; }
                }
            }
            if (age >= 220) { cleanup(level, player); return true; }
        }

        // ==========================================
        // VARYASYON 1: SİNSİ İZLEYİCİ
        // ==========================================
        else if (variation == 1) {
            if (age > 20 && age < 160 && age % 25 == 0) playSafeSound(level, player, "entity.warden.heartbeat", 1.5f, 0.5f);
            if (age == 160) {
                double dist = 10.0 + level.field_9229.method_43058() * 5.0; 
                double angle = (level.field_9229.method_43056() ? 1 : -1) * 0.7;
                spawnedStalker = spawnStalker(level, player, dist, angle, "rift_watcher");
                playSafeSound(level, player, "ambient.cave", 2.0f, 0.1f);
            }
            if (age > 160 && age < 260) {
                if (spawnedStalker != null && spawnedStalker.method_5805()) {
                    class_243 toStalker = spawnedStalker.method_19538().method_1020(player.method_19538()).method_1029();
                    if (player.method_5720().method_1026(toStalker) > 0.85 || age == 250) {
                        level.method_65096(class_2398.field_11237, spawnedStalker.method_23317(), spawnedStalker.method_23318() + 1.5, spawnedStalker.method_23321(), 30, 0.5, 1.0, 0.5, 0.05);
                        if (age != 250) playSafeSound(level, player, "entity.phantom.flap", 2.0f, 0.5f);
                        spawnedStalker.method_31472();
                        spawnedStalker = null;
                    }
                }
            }
            if (age >= 300) { cleanup(level, player); return true; }
        }

        // ==========================================
        // VARYASYON 2: POLTERGEIST / PARANOYA
        // ==========================================
        else if (variation == 2) {
            if (age == 40) player.method_6092(new class_1293(class_1294.field_5909, 300, 1, false, false));
            if (age > 60 && age < 240) {
                if (age % 30 == 0) playSafeSound(level, player, "entity.warden.heartbeat", 1.0f, 0.5f);
                if (age % 45 == 0) playSafeSound(level, player, "entity.player.step", 1.5f, 0.8f); 
                if (age % 80 == 0) playSafeSound(level, player, "entity.player.breath", 2.0f, 0.1f);
            }
            if (age == 260) {
                class_243 back = player.method_5720().method_1021(-1.5);
                class_2338 markPos = class_2338.method_49637(player.method_23317() + back.field_1352, player.method_23318(), player.method_23321() + back.field_1350);
                if (level.method_22347(markPos)) {
                    class_2248 groundBlock = level.method_8320(markPos.method_10074()).method_26204();
                    if (groundBlock == class_2246.field_10219 || groundBlock == class_2246.field_10566 || groundBlock == class_2246.field_10340 || groundBlock == class_2246.field_28888 || groundBlock == class_2246.field_10102) {
                        level.method_8652(markPos, class_2246.field_22423.method_9564(), 3);
                        level.method_65096(class_2398.field_23190, markPos.method_10263()+0.5, markPos.method_10264()+1, markPos.method_10260()+0.5, 60, 0.5, 0.5, 0.5, 0.05);
                        playSafeSound(level, player, "block.respawn_anchor.set_spawn", 1.0f, 0.5f);
                    }
                }
            }
            if (age >= 400) { cleanup(level, player); return true; }
        }

        // ==========================================
        // VARYASYON 3: ANOMALİ & 4. DUVAR (Uzun Psikolojik Çöküş)
        // ==========================================
        else if (variation == 3) {
            // Çıldırmış, giderek hızlanan kalp atışları
            if (age == 40 || age == 80 || age == 110 || age == 130 || age == 145 || age == 155) {
                playSafeSound(level, player, "entity.warden.heartbeat", 2.0f, 0.5f);
            }
            
            // 8. Saniye (160. Tick) - Yükseliş ve Gerçekliğin Kopuşu
            if (age == 160) {
                // 5 saniye (100 tick) boyunca yavaşça havaya kalkar
                player.method_6092(new class_1293(class_1294.field_5902, 100, 0, false, false));
                // 10 saniye (200 tick) mide bulantısı
                player.method_6092(new class_1293(class_1294.field_5916, 200, 0, false, false)); 
                // 7 saniye (140 tick) kör edici karanlık
                player.method_6092(new class_1293(class_1294.field_38092, 140, 0, false, false));
                
                playSafeSound(level, player, "ambient.cave", 3.0f, 0.1f); // Çok derin bir uğultu
                playSafeSound(level, player, "entity.illusioner.prepare_blindness", 1.5f, 0.5f);
            }

            // Havada asılıyken etrafında hiçlik hissi veren partiküller ve yankılı, yavaş sesler
            if (age > 160 && age < 260 && age % 20 == 0) {
                level.method_65096(class_2398.field_23190, player.method_23317(), player.method_23318() + 1, player.method_23321(), 40, 1.0, 1.0, 1.0, 0.01);
                playSafeSound(level, player, "block.amethyst_block.chime", 2.0f, 0.1f); // Çarpık, yavaş zil sesi
            }

            // 11. Saniye (220. Tick) - Zihne Kazınan Mesaj
            if (age == 220) {
                player.method_6092(new class_1293(class_1294.field_5919, 60, 0, false, false)); // Mesajla birlikte tam körlük
                player.method_7353(class_2561.method_43470("§4§k|||§r §c... uyan ...§r §4§k|||§r"), true);
                playSafeSound(level, player, "entity.enderman.stare", 1.0f, 0.5f); // Rahatsız edici statik ses
            }

            // 13. Saniye (260. Tick) - Düşüş ve İllüzyonun Bitmesi
            if (age == 260) { 
                player.method_6016(class_1294.field_5902); 
                playSafeSound(level, player, "entity.player.breath", 2.0f, 1.5f); // Panikle uyanmış gibi derin bir nefes
            }

            // Yere düşme hissiyatı
            if (age == 275) {
                playSafeSound(level, player, "entity.warden.heartbeat", 3.0f, 0.1f); 
            }

            if (age >= 360) { cleanup(level, player); return true; }
        }

        return false;
    }

    private class_1309 spawnStalker(class_3218 level, class_3222 player, double distance, double angleOffsetRadians, String tagLabel) {
        class_243 look = player.method_5720();
        double cos = Math.cos(angleOffsetRadians);
        double sin = Math.sin(angleOffsetRadians);
        
        double rx = look.field_1352 * cos - look.field_1350 * sin;
        double rz = look.field_1352 * sin + look.field_1350 * cos;
        
        class_243 offsetVec = new class_243(rx, 0, rz).method_1029().method_1021(distance);
        class_2338 spawnPos = class_2338.method_49637(player.method_23317() + offsetVec.field_1352, player.method_23318(), player.method_23321() + offsetVec.field_1350);

        int tries = 0;
        while (!level.method_22347(spawnPos) && tries < 5) { spawnPos = spawnPos.method_10084(); tries++; }
        tries = 0;
        while (level.method_22347(spawnPos.method_10074()) && tries < 5) { spawnPos = spawnPos.method_10074(); tries++; }

        if (!level.method_22347(spawnPos)) {
            if (distance > 5.0) {
                return null; 
            } else {
                spawnPos = class_2338.method_49637(player.method_23317() + offsetVec.field_1352, player.method_23318() + 1, player.method_23321() + offsetVec.field_1350);
            }
        }

        Optional<class_1299<?>> optionalType = class_7923.field_41177.method_17966(net.minecraft.class_2960.method_60655("riftbound", "rift_sentinel"));
        if (optionalType.isPresent()) {
            net.minecraft.class_1297 stalker = optionalType.get().method_5883(level, net.minecraft.class_3730.field_16467);
            if (stalker instanceof class_1309 living) {
                living.method_5814(spawnPos.method_10263() + 0.5, spawnPos.method_10264(), spawnPos.method_10260() + 0.5);
                
                double dX = player.method_23317() - living.method_23317();
                double dZ = player.method_23321() - living.method_23321();
                float yaw = (float)(Math.atan2(dZ, dX) * (180D / Math.PI)) - 90.0F;
                living.method_36456(yaw);
                living.field_6241 = yaw;
                living.field_6283 = yaw;

                class_2487 tag = new class_2487();
                living.method_5647(tag);
                tag.method_10556("NoAI", true);
                tag.method_10556("Silent", true);
                tag.method_10556("Invulnerable", true);
                living.method_5651(tag);
                
                living.method_5780(tagLabel);
                level.method_8649(living);
                return living;
            }
        }
        return null;
    }
}