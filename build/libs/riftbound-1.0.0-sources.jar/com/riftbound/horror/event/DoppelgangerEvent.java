package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class DoppelgangerEvent extends HorrorEvent {
    public DoppelgangerEvent() {
        super("riftbound:doppelganger", 200);
    }
    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }
    @Override
    public void cleanup(class_3218 level, class_3222 player) {}
    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        if (age == 1) {
            player.method_64398(class_2561.method_43470("§e[Bilinmeyen] oyuna katıldı"));
        }
        if (age == 80) {
            level.method_8396(null, player.method_24515(), class_3417.field_19149, class_3419.field_15256, 1.0f, 1.0f);
        }
        if (age == 160) {
            level.method_8396(null, player.method_24515(), class_3417.field_15115, class_3419.field_15256, 1.0f, 1.0f);
        }
        return age >= 200;
    }
}