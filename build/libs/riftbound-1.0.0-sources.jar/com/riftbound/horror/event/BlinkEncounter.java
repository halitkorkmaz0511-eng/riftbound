package com.riftbound.horror.event;
import com.riftbound.horror.HorrorState;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class BlinkEncounter extends HorrorEvent {
    public BlinkEncounter() { super("riftbound:blink", 8); }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        if (age == 1) {
            player.method_6092(new class_1293(class_1294.field_5919, 40, 0, false, false));
            playSafeSound(level, player, "entity.enderman.scream", 1.5f, 0.3f);
        }
        
        if (age >= 40) {
            return true; // Kisa olay 2 saniyede biter
        }
        return false;
    }
}