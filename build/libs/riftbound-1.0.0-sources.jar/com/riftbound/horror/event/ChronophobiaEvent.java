package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ChronophobiaEvent extends HorrorEvent {
    public ChronophobiaEvent() {
        super("riftbound:chronophobia", 600);
    }
    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }
    @Override
    public void cleanup(class_3218 level, class_3222 player) {}
    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        level.method_29199(18000);
        if (age == 1) {
             player.method_64398(class_2561.method_43470("§cZaman durdu... Odada yalnız değilsin."));
        }
        return age >= 600;
    }
}