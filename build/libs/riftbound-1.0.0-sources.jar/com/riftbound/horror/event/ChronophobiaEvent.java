package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ChronophobiaEvent extends HorrorEvent {
    public ChronophobiaEvent() {
        super("riftbound:chronophobia", 1800); // 90 Saniye sürer
    }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }

    @Override
    public void cleanup(class_3218 level, class_3222 player) {}

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        // Zamanı sonsuz gece yarısına (18000) kilitle
        level.method_29199(18000);

        // Oyuncu yatağa yatmaya çalışırsa anında kaldır ve korkunç mesajı ver
        if (player.method_6113()) {
            player.method_18400();
            player.method_64398(class_2561.method_43470("§c§lŞu an uyuyamazsın, odada yalnız değilsin."));
        }
        return false;
    }
}