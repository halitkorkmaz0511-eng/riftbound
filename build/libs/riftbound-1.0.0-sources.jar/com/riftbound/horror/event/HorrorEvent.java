package com.riftbound.horror.event;
import com.riftbound.horror.HorrorState;
import java.util.Optional;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_7923;

public abstract class HorrorEvent {
    private final String id;
    private final int weight;

    public HorrorEvent(String id, int weight) {
        this.id = id;
        this.weight = weight;
    }

    public String getId() { return id; }
    public int getWeight() { return weight; }

    public abstract boolean canTrigger(class_3218 level, class_3222 player);
    public abstract boolean tick(class_3218 level, class_3222 player, HorrorState state, long ageInTicks);
    public void cleanup(class_3218 level, class_3222 player) {}

    protected void playSafeSound(class_3218 level, class_3222 player, String soundId, float vol, float pitch) {
        Optional<class_3414> opt = class_7923.field_41172.method_17966(net.minecraft.class_2960.method_60655("minecraft", soundId));
        if (opt.isPresent()) {
            class_3414 se = opt.get();
            level.method_8396(null, player.method_24515(), se, class_3419.field_15251, vol, pitch);
        }
    }
}