package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1538;
import net.minecraft.class_1639;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;

public class TheUninvitedEvent extends HorrorEvent {
    
    private class_1639 stalker = null;
    private class_2338 targetPos = null;
    private List<class_2338> fireBlocks = new ArrayList<>();
    
    private boolean wasLooking = true;
    private boolean isJumpscaring = false;
    private long jumpscareTick = 0;
    
    // MÜCADELE (QTE) DEĞİŞKENLERİ
    private int catchCount = 0;
    private boolean isStruggling = false;
    private long struggleStartTick = 0;
    private boolean prevSneaking = false;
    private int struggleProgress = 0;

    private final String[] whispers = {
        "§8§o... neden kaçıyorsun? ...",
        "§8§o... arkana bakma ...",
        "§8§o... çok yavaşsın ..."
    };

    public TheUninvitedEvent() { 
        super("riftbound:the_uninvited", 120); 
    }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) { return true; }

    @Override
    public void cleanup(class_3218 level, class_3222 player) {
        if (stalker != null && stalker.method_5805()) { stalker.method_31472(); stalker = null; }
        for (class_2338 pos : fireBlocks) {
            if (level.method_8320(pos).method_27852(class_2246.field_22089)) level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
        }
        fireBlocks.clear();
        player.method_6016(class_1294.field_5919);
        player.method_6016(class_1294.field_5909);
    }

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        if (age == 1) {
            stalker = null; targetPos = null; fireBlocks.clear();
            wasLooking = true; isJumpscaring = false;
            catchCount = 0; isStruggling = false; struggleProgress = 0;
            
            player.method_64398(class_2561.method_43470("§7§o[Sistem] Kusursuz Kovalamaca Modu Aktif..."));
            
            class_243 look = player.method_5720();
            for(int d = 15; d <= 30; d+=3) {
                double angleOffset = (level.field_9229.method_43058() - 0.5) * 0.8; 
                double rx = look.field_1352 * Math.cos(angleOffset) - look.field_1350 * Math.sin(angleOffset);
                double rz = look.field_1352 * Math.sin(angleOffset) + look.field_1350 * Math.cos(angleOffset);
                class_2338 testPos = findGround(level, class_2338.method_49637(player.method_23317() + rx * d, player.method_23318(), player.method_23321() + rz * d));
                if (testPos != null && isUnderTree(level, testPos)) { targetPos = testPos; break; }
            }
            if (targetPos == null) targetPos = findGround(level, class_2338.method_49637(player.method_23317() + look.field_1352 * 22, player.method_23318(), player.method_23321() + look.field_1350 * 22));

            if (targetPos != null) {
                player.method_6092(new class_1293(class_1294.field_5919, 60, 0, false, false, false));
                level.method_8396(null, player.method_24515(), class_3417.field_14564.comp_349(), class_3419.field_15256, 3.0f, 0.1f);
            } else return true; 
        }

        if (age > 1 && age < 60 && age % 20 == 0) level.method_8396(null, player.method_24515(), class_3417.field_38068, class_3419.field_15256, 2.0f, 0.5f + (age / 60.0f));

        if (age == 60 && targetPos != null) {
            player.method_6016(class_1294.field_5919);
            class_1538 lightning = class_1299.field_6112.method_5883(level, net.minecraft.class_3730.field_16467);
            if (lightning != null) {
                lightning.method_29495(class_243.method_24955(targetPos));
                lightning.method_29498(true); level.method_8649(lightning);
            }
            level.method_8396(null, player.method_24515(), class_3417.field_14865, class_3419.field_15256, 5.0f, 0.8f);
            level.method_8396(null, player.method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15256, 3.0f, 0.5f);

            stalker = class_1299.field_6076.method_5883(level, net.minecraft.class_3730.field_16467);
            if (stalker != null) {
                stalker.method_5814(targetPos.method_10263() + 0.5, targetPos.method_10264(), targetPos.method_10260() + 0.5);
                stalker.method_5803(true); stalker.method_5977(true); stalker.method_5684(true);
                stalker.method_5673(class_1304.field_6173, class_1799.field_8037);
                level.method_8649(stalker);
                
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (level.field_9229.method_43056()) {
                            class_2338 firePos = targetPos.method_10069(dx, 0, dz);
                            if (level.method_22347(firePos) && !level.method_22347(firePos.method_10074())) {
                                level.method_8652(firePos, class_2246.field_22089.method_9564(), 3);
                                fireBlocks.add(firePos); 
                            }
                        }
                    }
                }
                level.method_8396(null, targetPos, class_3417.field_38072, class_3419.field_15256, 4.0f, 0.5f);
                player.method_64398(class_2561.method_43470("§8§o... gölgelerde yerin hazır ..."));
            }
        }

        if (age == 160 && stalker != null) {
            for (class_2338 pos : fireBlocks) {
                if (level.method_8320(pos).method_27852(class_2246.field_22089)) {
                    level.method_8652(pos, class_2246.field_10124.method_9564(), 3);
                    level.method_65096(class_2398.field_11237, pos.method_10263(), pos.method_10264(), pos.method_10260(), 10, 0.2, 0.2, 0.2, 0.01);
                }
            }
            fireBlocks.clear();
            level.method_8396(null, stalker.method_24515(), class_3417.field_15102, class_3419.field_15256, 1.0f, 0.5f);
        }

        // --- ÖLÜM (FİNAL JUMPSCARE) ANİMASYONU ---
        if (isJumpscaring) {
            if (age > jumpscareTick + 20) {
                level.method_65096(class_2398.field_11237, stalker.method_23317(), stalker.method_23318() + 1.0, stalker.method_23321(), 100, 0.5, 1.5, 0.5, 0.01);
                cleanup(level, player);
                return true;
            }
            return false;
        }

        // --- MÜCADELE (QTE) DURUMU ---
        if (isStruggling && stalker != null && stalker.method_5805()) {
            player.method_6092(new class_1293(class_1294.field_5909, 10, 4, false, false, false)); // Yürümeni aşırı yavaşlatır
            
            if (age % 5 == 0) {
                player.method_7353(class_2561.method_43470("§c§l>>> KURTULMAK İÇİN 'SHIFT' (EĞİLME) TUŞUNA ARD ARDA BAS! <<<"), true);
            }

            boolean isSneaking = player.method_18276();
            if (isSneaking && !prevSneaking) {
                struggleProgress++;
                level.method_8396(null, player.method_24515(), class_3417.field_15016, class_3419.field_15248, 1.0f, 1.0f);
            }
            prevSneaking = isSneaking;

            if (struggleProgress >= 3) {
                // BAŞARILI KAÇIŞ!
                isStruggling = false;
                player.method_7353(class_2561.method_43470("§a§l>>> İTTİN! KAÇ! <<<"), true);
                level.method_8396(null, player.method_24515(), class_3417.field_14742, class_3419.field_15251, 1.0f, 0.5f);
                
                // Yaratığı 15 blok geriye fırlat (Kovalamaca devam etsin)
                class_243 away = player.method_5720().method_1021(-15.0);
                class_2338 backPos = findGround(level, class_2338.method_49637(player.method_23317() + away.field_1352, player.method_23318() + 1, player.method_23321() + away.field_1350));
                if (backPos != null) stalker.method_5859(backPos.method_10263(), backPos.method_10264(), backPos.method_10260());
                else stalker.method_5859(player.method_23317() + away.field_1352, player.method_23318(), player.method_23321() + away.field_1350);
                
            } else if (age > struggleStartTick + 60) {
                // 3 Saniye içinde basamadı = BAŞARISIZ (ÖLÜM)
                isStruggling = false;
                catchCount = 3; // Direkt final infazına zorla
            }
            
            return false; // Mücadele bitene kadar alt kısımdaki kovalama mantığını durdur!
        }

        // --- KOVALAMA MANTIGI ---
        if (age > 160 && stalker != null && stalker.method_5805()) {
            class_243 toPlayer = player.method_19538().method_1020(stalker.method_19538());
            double dist = toPlayer.method_1033();
            class_243 look = player.method_5720();
            class_243 toStalker = stalker.method_19538().method_1020(player.method_19538()).method_1029();
            boolean isLooking = look.method_1026(toStalker) > 0.25;

            // YAKALANMA ŞARTI (Yaklaşırsa VEYA Mücadeleyi Kaybederse tetiklenir! Artık bakıp bakmaması umrumuzda değil)
            if (dist < 2.5 || catchCount >= 3) {
                
                if (catchCount < 2) {
                    // MİNİ-JUMPSCARE VE MÜCADELE BAŞLANGICI
                    catchCount++;
                    isStruggling = true;
                    struggleStartTick = age;
                    struggleProgress = 0;

                    // 1.5 Blok önüne ışınla ve yüzüne baktır
                    class_243 flatLook = new class_243(look.field_1352, 0, look.field_1350).method_1029();
                    class_243 facePos = player.method_19538().method_1019(flatLook.method_1021(1.5));
                    class_2338 groundPos = findGround(level, class_2338.method_49637(facePos.field_1352, player.method_23318() + 1, facePos.field_1350));
                    if (groundPos != null) stalker.method_5859(facePos.field_1352, groundPos.method_10264(), facePos.field_1350);
                    else stalker.method_5859(facePos.field_1352, player.method_23318(), facePos.field_1350);
                    
                    float yaw = (float)(Math.atan2(-flatLook.field_1350, -flatLook.field_1352) * (180D / Math.PI)) - 90.0F;
                    stalker.method_36456(yaw);
                    stalker.field_6241 = yaw;
                    stalker.field_6283 = yaw;

                    level.method_8396(null, player.method_24515(), class_3417.field_15027, class_3419.field_15251, 3.0f, 0.5f);
                    player.method_64397(level, player.method_48923().method_48830(), 2.0f); // 1 Kalp hasar
                    
                } else {
                    // 3. YAKALANMA (VEYA SHIFT'E BASAMAMA) = ÖLÜMCÜL İNFAZ
                    isJumpscaring = true;
                    jumpscareTick = age;
                    
                    // Tam gözünün içine (0.5 blok) girer
                    class_243 flatLook = new class_243(look.field_1352, 0, look.field_1350).method_1029();
                    class_243 facePos = player.method_19538().method_1019(flatLook.method_1021(0.8));
                    stalker.method_5859(facePos.field_1352, player.method_23318(), facePos.field_1350);
                    
                    float yaw = (float)(Math.atan2(-flatLook.field_1350, -flatLook.field_1352) * (180D / Math.PI)) - 90.0F;
                    stalker.method_36456(yaw);
                    stalker.field_6241 = yaw;
                    
                    level.method_8396(null, player.method_24515(), class_3417.field_14713, class_3419.field_15251, 5.0f, 0.5f);
                    player.method_6092(new class_1293(class_1294.field_5919, 40, 0, false, false, false));
                    player.method_64397(level, player.method_48923().method_48830(), 40.0f); // 20 Kalp (Tek atar)
                }
            }
            // OYUNCU KAÇIYOR - YAKLAŞ
            else if (!isLooking) {
                class_243 dir = toPlayer.method_1029();
                double speed = 0.38; // Senden daha hızlı
                if (dist < 10.0) speed = 0.20; // Yakınlaşınca seninle oynar
                if (dist > 25.0) speed = 0.55; // Uzaklaşırsan depar atar
                
                stalker.method_5859(stalker.method_23317() + dir.field_1352 * speed, stalker.method_23318(), stalker.method_23321() + dir.field_1350 * speed);
                
                float yaw = (float)(Math.atan2(dir.field_1350, dir.field_1352) * (180D / Math.PI)) - 90.0F;
                stalker.method_36456(yaw);
                stalker.field_6241 = yaw;
                stalker.field_6283 = yaw; // Vücudunu da düzgün çevir

                if (age % 8 == 0) level.method_8396(null, stalker.method_24515(), class_3417.field_14955, class_3419.field_15251, 2.5f, 0.6f);
            } 
            // OYUNCU BAKIYOR - DON
            else {
                if (!wasLooking) {
                    level.method_8396(null, stalker.method_24515(), class_3417.field_38068, class_3419.field_15251, 3.0f, 1.5f);
                    if (level.field_9229.method_43048(100) < 30) player.method_64398(class_2561.method_43470(whispers[level.field_9229.method_43048(whispers.length)]));
                }
            }
            wasLooking = isLooking;
        }

        if (age > 2000) { // Olay en fazla 100 saniye sürebilir
            level.method_65096(class_2398.field_11237, stalker.method_23317(), stalker.method_23318() + 1.0, stalker.method_23321(), 100, 0.5, 1.5, 0.5, 0.01);
            cleanup(level, player);
            return true;
        }

        return false;
    }

    private class_2338 findGround(class_3218 level, class_2338 pos) {
        class_2338 current = pos;
        int tries = 0;
        while (level.method_22347(current.method_10074()) && tries < 20) { current = current.method_10074(); tries++; }
        tries = 0;
        while (!level.method_22347(current) && tries < 20) { current = current.method_10084(); tries++; }
        if (level.method_22347(current) && !level.method_22347(current.method_10074())) return current;
        return null;
    }

    private boolean isUnderTree(class_3218 level, class_2338 pos) {
        for (int y = 2; y < 15; y++) {
            if (level.method_8320(pos.method_10086(y)).method_26164(class_3481.field_15503) || level.method_8320(pos.method_10086(y)).method_26164(class_3481.field_15475)) return true;
        }
        return false;
    }
}