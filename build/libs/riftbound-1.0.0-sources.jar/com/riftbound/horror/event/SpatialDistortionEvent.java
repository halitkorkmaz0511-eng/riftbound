package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class SpatialDistortionEvent extends HorrorEvent {
    private final Map<UUID, class_243> startPositions = new HashMap<>();

    public SpatialDistortionEvent() {
        super("riftbound:spatial_distortion", 600); // 30 saniye boyunca döngüde kalır
    }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) {
        return true; 
    }

    @Override
    public void cleanup(class_3218 level, class_3222 player) {
        startPositions.remove(player.method_5667());
    }

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        UUID uuid = player.method_5667();
        
        if (age == 1) {
            startPositions.put(uuid, player.method_19538());
            player.method_64398(class_2561.method_43470("§8§oHava aniden ağırlaştı..."));
            
            // Korkutucu ambiyans sesi
            Object soundObj = class_3417.field_14564;
            net.minecraft.class_3414 sound = null;
            if (soundObj instanceof net.minecraft.class_6880) {
                sound = (net.minecraft.class_3414) ((net.minecraft.class_6880<?>) soundObj).comp_349();
            } else if (soundObj instanceof net.minecraft.class_3414) {
                sound = (net.minecraft.class_3414) soundObj;
            }
            if (sound != null) {
                level.method_8396(null, player.method_24515(), sound, class_3419.field_15256, 1.0f, 0.5f);
            }
        }

        if (!startPositions.containsKey(uuid)) return true;

        class_243 startPos = startPositions.get(uuid);
        double distance = player.method_19538().method_1022(startPos);

        // Oyuncu 10 blok ileri gittiği an hissettirmeden başladığı yere geri ışınla!
        if (distance > 10.0) {
            player.field_13987.method_14363(startPos.field_1352, startPos.field_1351, startPos.field_1350, player.method_36454(), player.method_36455());
            
            // Kafasını karıştırmak için her başa döndüğünde hafif bir fısıltı
            Object whisperObj = class_3417.field_14967; 
            net.minecraft.class_3414 whisper = null;
            if (whisperObj instanceof net.minecraft.class_6880) {
                whisper = (net.minecraft.class_3414) ((net.minecraft.class_6880<?>) whisperObj).comp_349();
            } else if (whisperObj instanceof net.minecraft.class_3414) {
                whisper = (net.minecraft.class_3414) whisperObj;
            }
            if (whisper != null) {
                level.method_8396(null, player.method_24515(), whisper, class_3419.field_15256, 0.2f, 0.1f);
            }
        }

        return false;
    }
}