package com.riftbound.horror.event;

import com.riftbound.horror.HorrorState;
import net.minecraft.class_1928;
import net.minecraft.class_2761;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class FalseMorningEvent extends HorrorEvent {
    
    public FalseMorningEvent() { 
        super("riftbound:false_morning", 4); 
    }

    @Override
    public boolean canTrigger(class_3218 level, class_3222 player) {
        // Yalnızca gece vakti ve yüzeyde/yüzeye yakınken (Y > 50) tetiklenir
        return level.method_23886() && player.method_23318() > 50; 
    }

    @Override
    public void cleanup(class_3218 level, class_3222 player) {
        // İllüzyon bittiğinde veya oyuncu çıktığında GERÇEK zamanı geri yükle
        player.field_13987.method_14364(new class_2761(
            level.method_8510(), 
            level.method_8532(), 
            level.method_64395().method_8355(class_1928.field_19396)
        ));
    }

    @Override
    public boolean tick(class_3218 level, class_3222 player, HorrorState state, long age) {
        // 10 Saniyelik (200 Tick) Sahte Sabah İllüzyonu
        if (age == 1) {
            // Sabah hissi vermek için sahte papağan/kuş sesleri
            playSafeSound(level, player, "entity.parrot.ambient", 1.0f, 1.0f); 
        }

        if (age > 1 && age < 200) {
            // Her tick client'a "Saat şu an sabah (1000L)" diye sahte paket gönderiyoruz.
            // Bunu her tick yapıyoruz ki Minecraft'ın kendi senkronizasyonu illüzyonu bozmasın.
            player.field_13987.method_14364(new class_2761(level.method_8510(), 1000L, false));
            
            // Arada bir kuş sesleri
            if (age % 50 == 0) {
                playSafeSound(level, player, "entity.parrot.ambient", 0.6f, (float)(0.8 + level.field_9229.method_43058() * 0.4));
            }
        }

        if (age == 200) {
            // İllüzyon Kırılır - Geceye aniden geri dönüş
            cleanup(level, player); // Gerçek karanlık paketi yollanır
            
            // Kırılma şoku (Büyük, boğuk bir patlama ve ışınlanma sesi)
            playSafeSound(level, player, "ambient.cave", 3.0f, 0.1f);
            playSafeSound(level, player, "entity.enderman.teleport", 2.0f, 0.5f);
        }

        if (age >= 240) {
            return true;
        }

        return false;
    }
}