package com.riftbound;

import com.riftbound.client.render.RiftSentinelModel;
import com.riftbound.client.render.RiftSentinelRenderer;
import com.riftbound.entity.ModEntities;
import com.riftbound.network.RiftboundPayloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_6344;
import org.lwjgl.glfw.GLFW;

public class RiftboundClient implements ClientModInitializer {
    private static class_304 dashKey;
    private static class_304 pulseKey;
    private static class_304 shieldKey;

    public static int clientUnlockedTier = 0;
    public static int clientDashCd = 0;
    public static int clientPulseCd = 0;
    public static int clientShieldCd = 0;
    public static int clientShieldActive = 0;

    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(RiftSentinelRenderer.LAYER_LOCATION, RiftSentinelModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.RIFT_SENTINEL, RiftSentinelRenderer::new);
        EntityRendererRegistry.register(ModEntities.RIFT_BOLT, class_6344::new);

        dashKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.riftbound.rift_dash", class_3675.class_307.field_1668, GLFW.GLFW_KEY_R, "category.riftbound.abilities"));
        pulseKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.riftbound.void_pulse", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, "category.riftbound.abilities"));
        shieldKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.riftbound.rift_shield", class_3675.class_307.field_1668, GLFW.GLFW_KEY_V, "category.riftbound.abilities"));

        ClientPlayNetworking.registerGlobalReceiver(RiftboundPayloads.SyncProgressionPayload.TYPE, (payload, context) -> {
            context.client().execute(() -> {
                clientUnlockedTier = payload.unlockedTier();
                clientDashCd = payload.dashCooldown();
                clientPulseCd = payload.pulseCooldown();
                clientShieldCd = payload.shieldCooldown();
                clientShieldActive = payload.shieldActiveTicks();
            });
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (dashKey.method_1436()) {
                ClientPlayNetworking.send(new RiftboundPayloads.UseAbilityPayload(1));
            }
            while (pulseKey.method_1436()) {
                ClientPlayNetworking.send(new RiftboundPayloads.UseAbilityPayload(2));
            }
            while (shieldKey.method_1436()) {
                ClientPlayNetworking.send(new RiftboundPayloads.UseAbilityPayload(3));
            }
        });

        HudRenderCallback.EVENT.register((guiGraphics, deltaTracker) -> {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 == null || mc.field_1690.field_1842 || clientUnlockedTier <= 0) return;

            int x = 10;
            int y = guiGraphics.method_51443() - 42;

            String dashText = formatAbilityStatus("[R] Dash", 1, clientDashCd, 0);
            guiGraphics.method_51439(mc.field_1772, class_2561.method_43470(dashText), x, y, 0xFFFFFF, true);

            if (clientUnlockedTier >= 2) {
                String pulseText = formatAbilityStatus("[G] Void Pulse", 2, clientPulseCd, 0);
                guiGraphics.method_51439(mc.field_1772, class_2561.method_43470(pulseText), x, y + 12, 0xFFFFFF, true);
            }
            if (clientUnlockedTier >= 3) {
                String shieldText = formatAbilityStatus("[V] Rift Shield", 3, clientShieldCd, clientShieldActive);
                guiGraphics.method_51439(mc.field_1772, class_2561.method_43470(shieldText), x, y + 24, 0xFFFFFF, true);
            }
        });
    }

    private static String formatAbilityStatus(String label, int tier, int cdTicks, int activeTicks) {
        if (clientUnlockedTier < tier) return "§8" + label + ": LOCKED";
        if (activeTicks > 0) return "§b" + label + ": ACTIVE (" + String.format("%.1fs", activeTicks / 20.0f) + ")";
        if (cdTicks > 0) return "§7" + label + ": " + String.format("%.1fs", cdTicks / 20.0f);
        return "§d" + label + ": §aREADY";
    }
}
