package com.riftbound.command;

import com.riftbound.world.RiftMonolithGenerator;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

import static net.minecraft.class_2170.method_9247;

public class RiftCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(method_9247("riftbound")
                .then(method_9247("spawn_monolith").executes(context -> {
                    class_3218 level = context.getSource().method_9225();
                    class_2338 pos = class_2338.method_49638(context.getSource().method_9222());
                    RiftMonolithGenerator.buildMonolith(level, pos);
                    context.getSource().method_9226(() -> class_2561.method_43470("Rift Monolith basariyla insa edildi!"), false);
                    return 1;
                }))
            );
        });
    }
}