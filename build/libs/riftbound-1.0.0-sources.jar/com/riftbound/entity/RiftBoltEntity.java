package com.riftbound.entity;

import com.riftbound.ability.AbilityManager;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1682;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class RiftBoltEntity extends class_1682 {
    public RiftBoltEntity(class_1299<? extends RiftBoltEntity> type, class_1937 level) {
        super(type, level);
        this.method_5875(true);
    }

    public RiftBoltEntity(class_1937 level, class_1309 shooter) {
        super(ModEntities.RIFT_BOLT, shooter.method_23317(), shooter.method_23320() - 0.2, shooter.method_23321(), level);
        this.method_7432(shooter);
        this.method_5875(true);
    }

    @Override
    protected void method_5693(net.minecraft.class_2945.class_9222 builder) {}

    @Override
    public void method_5773() {
        super.method_5773();
        if (this.field_6012 > 80) {
            this.method_31472();
            return;
        }
        if (this.method_37908().field_9236) {
            this.method_37908().method_8406(AbilityManager.RIFT_CYAN, this.method_23317(), this.method_23318(), this.method_23321(), 0, 0, 0);
            this.method_37908().method_8406(class_2398.field_11214, this.method_23317(), this.method_23318(), this.method_23321(), 0, 0, 0);
        }
    }

    @Override
    protected void method_7454(class_3966 result) {
        super.method_7454(result);
        if (!this.method_37908().field_9236 && this.method_37908() instanceof class_3218 serverLevel) {
            class_1297 hit = result.method_17782();
            class_1297 owner = this.method_24921();
            if (hit != owner && hit instanceof class_1309 living) {
                living.method_64397(serverLevel, this.method_48923().method_48815(this, owner), 9.0f);
                serverLevel.method_65096(AbilityManager.RIFT_PURPLE, hit.method_23317(), hit.method_23318() + 1.0, hit.method_23321(), 18, 0.3, 0.3, 0.3, 0.05);
                serverLevel.method_65096(class_2398.field_23190, hit.method_23317(), hit.method_23318() + 1.0, hit.method_23321(), 15, 0.2, 0.2, 0.2, 0.1);
                this.method_5783(class_3417.field_26942, 1.0f, 0.8f);
                this.method_31472();
            }
        }
    }

    @Override
    protected void method_24920(class_3965 result) {
        super.method_24920(result);
        if (!this.method_37908().field_9236 && this.method_37908() instanceof class_3218 serverLevel) {
            serverLevel.method_65096(AbilityManager.RIFT_CYAN, this.method_23317(), this.method_23318(), this.method_23321(), 12, 0.2, 0.2, 0.2, 0.05);
            this.method_5783(class_3417.field_26979, 0.8f, 1.2f);
            this.method_31472();
        }
    }
}
