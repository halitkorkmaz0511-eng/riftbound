package com.riftbound.entity;

import com.riftbound.RiftboundMod;
import com.riftbound.entity.boss.RiftSentinelEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModEntities {
    public static final class_5321<class_1299<?>> RIFT_SENTINEL_KEY =
            class_5321.method_29179(class_7924.field_41266, RiftboundMod.id("rift_sentinel"));

    public static final class_1299<RiftSentinelEntity> RIFT_SENTINEL = class_2378.method_39197(
            class_7923.field_41177,
            RIFT_SENTINEL_KEY,
            class_1299.class_1300.method_5903(RiftSentinelEntity::new, class_1311.field_6302)
                    .method_17687(1.4f, 3.2f)
                    .method_27299(10)
                    .method_5905(RIFT_SENTINEL_KEY)
    );

    public static final class_5321<class_1299<?>> RIFT_BOLT_KEY =
            class_5321.method_29179(class_7924.field_41266, RiftboundMod.id("rift_bolt"));

    public static final class_1299<RiftBoltEntity> RIFT_BOLT = class_2378.method_39197(
            class_7923.field_41177,
            RIFT_BOLT_KEY,
            class_1299.class_1300.<RiftBoltEntity>method_5903(RiftBoltEntity::new, class_1311.field_17715)
                    .method_17687(0.45f, 0.45f)
                    .method_27299(8)
                    .method_27300(2)
                    .method_5905(RIFT_BOLT_KEY)
    );

    public static void register() {
        FabricDefaultAttributeRegistry.register(RIFT_SENTINEL, RiftSentinelEntity.createAttributes());
    }
}
