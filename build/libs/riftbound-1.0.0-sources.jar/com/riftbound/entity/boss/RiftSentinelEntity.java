package com.riftbound.entity.boss;

import com.riftbound.ability.AbilityManager;
import com.riftbound.entity.RiftBoltEntity;
import com.riftbound.item.ModItems;
import com.riftbound.network.RiftboundPayloads;
import com.riftbound.progression.PlayerRiftData;
import com.riftbound.progression.RiftProgressionState;
import net.minecraft.class_1259;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1399;
import net.minecraft.class_1400;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3213;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7094;

public class RiftSentinelEntity extends class_1588 {
    public static final int STATE_IDLE = 0;
    public static final int STATE_STRIKE_WINDUP = 1;
    public static final int STATE_STRIKE_HIT = 2;
    public static final int STATE_STRIKE_RECOVERY = 3;
    public static final int STATE_VOID_WAVE_CHARGE = 4;
    public static final int STATE_RIFT_BOLTS = 5;
    public static final int STATE_PHASE_SHIFT = 6;
    public static final int STATE_DEATH_SEQUENCE = 7;

    private static final class_2940<Integer> ATTACK_STATE =
            class_2945.method_12791(RiftSentinelEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> ENRAGED =
            class_2945.method_12791(RiftSentinelEntity.class, class_2943.field_13323);

    private final class_3213 bossBar = new class_3213(
            class_2561.method_43470("§5§lRift Sentinel §7- §dDimensional Guardian"),
            class_1259.class_1260.field_5783,
            class_1259.class_1261.field_5791
    );

    public final class_7094 idleAnimationState = new class_7094();
    public final class_7094 strikeAnimationState = new class_7094();
    public final class_7094 voidWaveAnimationState = new class_7094();
    public final class_7094 phaseShiftAnimationState = new class_7094();
    public final class_7094 deathAnimationState = new class_7094();

    private int stateTimer = 0;
    private int globalCooldown = 40;
    private int strikeCooldown = 0;
    private int waveCooldown = 100;
    private int boltsCooldown = 60;
    private int shiftCooldown = 140;
    private int customDeathTicks = 0;

    public RiftSentinelEntity(class_1299<? extends class_1588> type, class_1937 level) {
        super(type, level);
        this.field_6194 = 250;
        this.method_5971();
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1588.method_26918()
                .method_26868(class_5134.field_23716, 300.0D)
                .method_26868(class_5134.field_23719, 0.27D)
                .method_26868(class_5134.field_23721, 14.0D)
                .method_26868(class_5134.field_23724, 10.0D)
                .method_26868(class_5134.field_23718, 0.85D)
                .method_26868(class_5134.field_23717, 48.0D);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(ATTACK_STATE, STATE_IDLE);
        builder.method_56912(ENRAGED, false);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(7, new class_1361(this, class_1657.class, 16.0F));
        this.field_6201.method_6277(8, new class_1376(this));

        this.field_6185.method_6277(1, new class_1399(this));
        this.field_6185.method_6277(2, new class_1400<>(this, class_1657.class, true));
    }

    public int getAttackState() {
        return this.field_6011.method_12789(ATTACK_STATE);
    }

    public void setAttackState(int state) {
        this.field_6011.method_12778(ATTACK_STATE, state);
        this.stateTimer = 0;
    }

    public boolean isEnraged() {
        return this.field_6011.method_12789(ENRAGED);
    }

    public void setEnraged(boolean enraged) {
        this.field_6011.method_12778(ENRAGED, enraged);
    }

    @Override
    public void method_5674(class_2940<?> key) {
        super.method_5674(key);
        if (this.method_37908().field_9236 && ATTACK_STATE.equals(key)) {
            int state = getAttackState();
            strikeAnimationState.method_41325();
            voidWaveAnimationState.method_41325();
            phaseShiftAnimationState.method_41325();
            if (state == STATE_STRIKE_WINDUP) {
                strikeAnimationState.method_41322(this.field_6012);
            } else if (state == STATE_VOID_WAVE_CHARGE) {
                voidWaveAnimationState.method_41322(this.field_6012);
            } else if (state == STATE_PHASE_SHIFT) {
                phaseShiftAnimationState.method_41322(this.field_6012);
            } else if (state == STATE_DEATH_SEQUENCE) {
                deathAnimationState.method_41322(this.field_6012);
            }
        }
    }

    public void triggerSpawnSequence() {
        if (this.method_37908() instanceof class_3218 serverLevel) {
            serverLevel.method_65096(class_2398.field_23190, method_23317(), method_23318() + 1.5, method_23321(), 60, 0.8, 1.5, 0.8, 0.15);
            serverLevel.method_65096(AbilityManager.RIFT_CYAN, method_23317(), method_23318() + 1.5, method_23321(), 40, 0.8, 1.5, 0.8, 0.05);
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_37908().field_9236) {
            this.idleAnimationState.method_41324(this.field_6012);
            spawnClientAmbientParticles();
            return;
        }

        class_3218 serverLevel = (class_3218) this.method_37908();
        this.bossBar.method_5408(this.method_6032() / this.method_6063());

        if (!isEnraged() && this.method_6032() > 0 && this.method_6032() <= this.method_6063() * 0.45f) {
            triggerEnragedPhase(serverLevel);
        }

        if (this.method_6032() <= 0 || getAttackState() == STATE_DEATH_SEQUENCE) {
            return;
        }

        int cdSpeed = isEnraged() ? 2 : 1;
        if (globalCooldown > 0) globalCooldown -= cdSpeed;
        if (strikeCooldown > 0) strikeCooldown -= cdSpeed;
        if (waveCooldown > 0) waveCooldown -= cdSpeed;
        if (boltsCooldown > 0) boltsCooldown -= cdSpeed;
        if (shiftCooldown > 0) shiftCooldown -= cdSpeed;

        class_1309 target = this.method_5968();
        if (target == null || !target.method_5805()) {
            if (getAttackState() != STATE_IDLE) setAttackState(STATE_IDLE);
            return;
        }

        this.method_5988().method_6226(target, 30.0F, 30.0F);
        double distSq = this.method_5858(target);

        if (getAttackState() == STATE_IDLE) {
            if (distSq > 9.0) {
                this.method_5942().method_6335(target, isEnraged() ? 1.35D : 1.05D);
            } else {
                this.method_5942().method_6340();
            }

            if (globalCooldown <= 0) {
                selectNextAttack(target, distSq);
            }
        } else {
            this.method_5942().method_6340();
            tickActiveAttackState(serverLevel, target);
        }
    }

    private void spawnClientAmbientParticles() {
        if (this.field_5974.method_43048(2) == 0) {
            double ox = (this.field_5974.method_43058() - 0.5) * 1.6;
            double oy = this.field_5974.method_43058() * 3.0;
            double oz = (this.field_5974.method_43058() - 0.5) * 1.6;
            this.method_37908().method_8406(isEnraged() ? AbilityManager.RIFT_CYAN : AbilityManager.RIFT_PURPLE,
                    this.method_23317() + ox, this.method_23318() + oy, this.method_23321() + oz, 0, 0.03, 0);
        }
    }

    private void triggerEnragedPhase(class_3218 serverLevel) {
        setEnraged(true);
        this.bossBar.method_5416(class_1259.class_1260.field_5780);
        this.bossBar.method_5413(class_2561.method_43470("§b§lRift Sentinel §7- §3§lOVERLOADED RIFT PHASE"));
        serverLevel.method_8396(null, method_24515(), class_3417.field_38075, class_3419.field_15251, 1.5f, 0.85f);
        serverLevel.method_65096(class_2398.field_38908, method_23317(), method_23318() + 1.8, method_23321(), 2, 0.2, 0.2, 0.2, 0.0);
        serverLevel.method_65096(AbilityManager.RIFT_CYAN, method_23317(), method_23318() + 1.5, method_23321(), 80, 1.5, 1.5, 1.5, 0.12);

        for (class_3222 player : bossBar.method_14092()) {
            player.method_7353(class_2561.method_43470("§b§l⚡ The Rift Sentinel destabilizes and enters its Enraged Phase!"), false);
        }
    }

    private void selectNextAttack(class_1309 target, double distSq) {
        if (distSq <= 16.0 && strikeCooldown <= 0 && this.method_6057(target)) {
            setAttackState(STATE_STRIKE_WINDUP);
            this.method_5783(class_3417.field_38064, 1.0f, 0.6f);
        } else if (distSq <= 49.0 && waveCooldown <= 0) {
            setAttackState(STATE_VOID_WAVE_CHARGE);
            this.method_5783(class_3417.field_14891, 1.4f, 0.6f);
        } else if (distSq > 36.0 && shiftCooldown <= 0) {
            setAttackState(STATE_PHASE_SHIFT);
            this.method_5783(class_3417.field_14738, 1.2f, 0.8f);
        } else if (boltsCooldown <= 0 && this.method_6057(target)) {
            setAttackState(STATE_RIFT_BOLTS);
            this.method_5783(class_3417.field_14970, 1.2f, 0.6f);
        }
    }

    private void tickActiveAttackState(class_3218 level, class_1309 target) {
        stateTimer++;
        int state = getAttackState();

        switch (state) {
            case STATE_STRIKE_WINDUP -> {
                class_243 forward = this.method_5720().method_18805(1, 0, 1).method_1029().method_1021(2.3);
                class_243 hitCenter = this.method_19538().method_1019(forward);
                drawWarningCircle(level, hitCenter, 2.2, AbilityManager.RIFT_PURPLE);

                if (stateTimer >= (isEnraged() ? 12 : 16)) {
                    setAttackState(STATE_STRIKE_HIT);
                }
            }
            case STATE_STRIKE_HIT -> {
                if (stateTimer == 1) {
                    class_243 forward = this.method_5720().method_18805(1, 0, 1).method_1029().method_1021(2.3);
                    class_243 hitCenter = this.method_19538().method_1019(forward);
                    level.method_8396(null, method_24515(), class_3417.field_15152.comp_349(), class_3419.field_15251, 1.1f, 1.2f);
                    level.method_65096(class_2398.field_11227, hitCenter.field_1352, hitCenter.field_1351 + 1.0, hitCenter.field_1350, 6, 0.8, 0.3, 0.8, 0.0);
                    level.method_65096(AbilityManager.RIFT_CYAN, hitCenter.field_1352, hitCenter.field_1351 + 0.3, hitCenter.field_1350, 35, 1.2, 0.2, 1.2, 0.08);

                    class_238 hitBox = new class_238(hitCenter.field_1352 - 2.3, hitCenter.field_1351 - 0.5, hitCenter.field_1350 - 2.3,
                            hitCenter.field_1352 + 2.3, hitCenter.field_1351 + 2.8, hitCenter.field_1350 + 2.3);
                    for (class_1309 victim : level.method_8390(class_1309.class, hitBox, e -> e != this && this.method_6057(e))) {
                        victim.method_64397(level, this.method_48923().method_48812(this), isEnraged() ? 18.0f : 14.0f);
                        class_243 kb = victim.method_19538().method_1020(this.method_19538()).method_1029().method_1021(1.1);
                        victim.method_5762(kb.field_1352, 0.35, kb.field_1350);
                    }
                }
                if (stateTimer >= 6) {
                    setAttackState(STATE_STRIKE_RECOVERY);
                }
            }
            case STATE_STRIKE_RECOVERY -> {
                if (stateTimer >= (isEnraged() ? 12 : 20)) {
                    strikeCooldown = 50;
                    globalCooldown = 20;
                    setAttackState(STATE_IDLE);
                }
            }
            case STATE_VOID_WAVE_CHARGE -> {
                double radius = 6.5;
                drawWarningCircle(level, this.method_19538(), radius, AbilityManager.RIFT_CYAN);
                drawWarningCircle(level, this.method_19538(), (stateTimer / 32.0) * radius, AbilityManager.RIFT_PURPLE);

                if (stateTimer == 10 || stateTimer == 20) {
                    level.method_8396(null, method_24515(), class_3417.field_38068, class_3419.field_15251, 1.5f, 1.4f);
                }

                if (stateTimer >= (isEnraged() ? 24 : 32)) {
                    level.method_8396(null, method_24515(), class_3417.field_38830, class_3419.field_15251, 1.4f, 0.75f);
                    level.method_65096(class_2398.field_11221, method_23317(), method_23318() + 0.5, method_23321(), 2, 0.5, 0.2, 0.5, 0.0);
                    drawWarningCircle(level, this.method_19538(), radius, AbilityManager.RIFT_CYAN);

                    class_238 waveBox = this.method_5829().method_1009(radius, 2.0, radius);
                    for (class_1309 victim : level.method_8390(class_1309.class, waveBox, e -> e != this && this.method_6057(e))) {
                        if (victim.method_5858(this) <= radius * radius) {
                            victim.method_64397(level, this.method_48923().method_48831(), isEnraged() ? 20.0f : 15.0f);
                            class_243 launch = victim.method_19538().method_1020(this.method_19538()).method_1029().method_1021(1.6);
                            victim.method_5762(launch.field_1352, 0.65, launch.field_1350);
                        }
                    }
                    waveCooldown = 160;
                    globalCooldown = 35;
                    setAttackState(STATE_IDLE);
                }
            }
            case STATE_RIFT_BOLTS -> {
                if (stateTimer == 8 || stateTimer == 16 || stateTimer == 24 || (isEnraged() && stateTimer == 32)) {
                    if (this.method_6057(target)) {
                        RiftBoltEntity bolt = new RiftBoltEntity(level, this);
                        class_243 dir = target.method_33571().method_1020(bolt.method_19538()).method_1029();
                        bolt.method_7485(dir.field_1352, dir.field_1351, dir.field_1350, 1.25f, 1.5f);
                        level.method_8649(bolt);
                        level.method_8396(null, method_24515(), class_3417.field_15000, class_3419.field_15251, 1.2f, 1.3f);
                    }
                }
                if (stateTimer >= 36) {
                    boltsCooldown = 110;
                    globalCooldown = 25;
                    setAttackState(STATE_IDLE);
                }
            }
            case STATE_PHASE_SHIFT -> {
                level.method_65096(class_2398.field_23190, method_23317(), method_23318() + 1.5, method_23321(), 12, 0.4, 0.9, 0.4, 0.08);
                if (stateTimer >= 12) {
                    performSafeTeleport(level, target);
                    shiftCooldown = 180;
                    globalCooldown = 20;
                    setAttackState(STATE_IDLE);
                }
            }
        }
    }

    private void performSafeTeleport(class_3218 level, class_1309 target) {
        class_243 oldPos = this.method_19538();
        for (int attempt = 0; attempt < 12; attempt++) {
            double angle = this.field_5974.method_43058() * Math.PI * 2.0;
            double dist = 4.0 + this.field_5974.method_43058() * 4.0;
            double tx = target.method_23317() + Math.cos(angle) * dist;
            double tz = target.method_23321() + Math.sin(angle) * dist;
            class_2338 candidate = class_2338.method_49637(tx, target.method_23318(), tz);

            for (int dy = 2; dy >= -3; dy--) {
                class_2338 check = candidate.method_10069(0, dy, 0);
                if (level.method_8320(check.method_10074()).method_51367() && level.method_22347(check) && level.method_22347(check.method_10084())) {
                    level.method_65096(AbilityManager.RIFT_PURPLE, oldPos.field_1352, oldPos.field_1351 + 1.5, oldPos.field_1350, 40, 0.4, 1.0, 0.4, 0.1);
                    level.method_8396(null, class_2338.method_49638(oldPos), class_3417.field_14879, class_3419.field_15251, 1.3f, 0.8f);

                    this.method_5859(check.method_10263() + 0.5, check.method_10264(), check.method_10260() + 0.5);

                    level.method_65096(class_2398.field_17909, method_23317(), method_23318() + 1.5, method_23321(), 1, 0, 0, 0, 0);
                    level.method_65096(AbilityManager.RIFT_CYAN, method_23317(), method_23318() + 1.5, method_23321(), 40, 0.4, 1.0, 0.4, 0.1);
                    level.method_8396(null, check, class_3417.field_14879, class_3419.field_15251, 1.3f, 1.2f);
                    return;
                }
            }
        }
    }

    private void drawWarningCircle(class_3218 level, class_243 center, double radius, net.minecraft.class_2394 particle) {
        int points = Math.max(16, (int) (radius * 10));
        for (int i = 0; i < points; i++) {
            double angle = (2 * Math.PI * i) / points;
            double px = center.field_1352 + Math.cos(angle) * radius;
            double pz = center.field_1350 + Math.sin(angle) * radius;
            level.method_65096(particle, px, center.field_1351 + 0.15, pz, 1, 0, 0, 0, 0);
        }
    }

    @Override
    protected void method_6108() {
        if (getAttackState() != STATE_DEATH_SEQUENCE) {
            setAttackState(STATE_DEATH_SEQUENCE);
        }
        customDeathTicks++;

        if (!this.method_37908().field_9236 && this.method_37908() instanceof class_3218 serverLevel) {
            double progress = customDeathTicks / 60.0;
            serverLevel.method_65096(class_2398.field_23190, method_23317(), method_23318() + 1.5 + progress, method_23321(),
                    8, 0.6 * (1.0 - progress), 0.8, 0.6 * (1.0 - progress), 0.1);
            serverLevel.method_65096(AbilityManager.RIFT_CYAN, method_23317(), method_23318() + 1.5, method_23321(), 5, 0.5, 0.8, 0.5, 0.05);

            if (customDeathTicks % 15 == 0) {
                serverLevel.method_8396(null, method_24515(), class_3417.field_23117.comp_349(), class_3419.field_15251, 1.2f, 0.6f + (float) progress);
            }

            if (customDeathTicks >= 60) {
                serverLevel.method_8396(null, method_24515(), class_3417.field_15195, class_3419.field_15251, 1.5f, 0.9f);
                serverLevel.method_65096(class_2398.field_11221, method_23317(), method_23318() + 1.5, method_23321(), 2, 0.2, 0.2, 0.2, 0);
                serverLevel.method_65096(class_2398.field_11207, method_23317(), method_23318() + 1.5, method_23321(), 80, 0.8, 0.8, 0.8, 0.25);

                this.method_5775(serverLevel, new class_1799(ModItems.RIFT_CORE, 1));

                RiftProgressionState state = RiftProgressionState.getServerState(serverLevel.method_8503());
                for (class_3222 player : bossBar.method_14092()) {
                    PlayerRiftData data = state.getPlayerData(player.method_5667());
                    data.sentinelKills++;
                    if (data.unlockedTier == 0) {
                        data.unlockedTier = 1;
                        player.method_64398(class_2561.method_43470("§5✦ [RIFTBOUND] §dThe Rift Sentinel collapses! §bRift Dash [R] §dhas been automatically unlocked, and a §5Rift Core §ddropped to unlock your next ability!"));
                    } else {
                        player.method_64398(class_2561.method_43470("§5✦ [RIFTBOUND] §dThe Rift Sentinel collapses! Use the dropped §5Rift Core §dto unlock your next ability tier."));
                    }
                    RiftboundPayloads.syncToClient(player, data);
                }
                state.setDirty();
                this.method_5650(class_5529.field_26998);
            }
        }
    }

    @Override
    public void method_5837(class_3222 player) {
        super.method_5837(player);
        this.bossBar.method_14088(player);
    }

    @Override
    public void method_5742(class_3222 player) {
        super.method_5742(player);
        this.bossBar.method_14089(player);
    }

    @Override
    public void method_5652(class_2487 tag) {
        super.method_5652(tag);
        tag.method_10556("Enraged", isEnraged());
    }

    @Override
    public void method_5749(class_2487 tag) {
        super.method_5749(tag);
        setEnraged(tag.method_10577("Enraged"));
        if (this.method_16914()) {
            this.bossBar.method_5413(this.method_5476());
        }
    }
}
