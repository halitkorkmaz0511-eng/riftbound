package com.riftbound.item;

import net.minecraft.class_10191;
import net.minecraft.class_10192;
import net.minecraft.class_10394;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;

public class RiftArmorItem extends class_1792 {
    public static final class_5321<class_10394> RIFT_ARMOR_ASSET = class_5321.method_29179(
        class_10191.field_55214,
        class_2960.method_60655("riftbound", "rift")
    );

    private final class_1304 slot;

    public RiftArmorItem(class_1304 slot, double armor, double toughness, String slotName, class_1793 properties) {
        super(properties
            .method_57348(createArmorAttributes(slot, armor, toughness, slotName))
            .method_57349(class_9334.field_54196, class_10192.method_64202(slot)
                .method_64205(class_3417.field_21866)
                .method_64204(RIFT_ARMOR_ASSET)
                .method_64203()
            )
        );
        this.slot = slot;
    }

    private static class_9285 createArmorAttributes(class_1304 slot, double armor, double toughness, String slotName) {
        class_9274 group = switch (slot) {
            case field_6169 -> class_9274.field_49223;
            case field_6174 -> class_9274.field_49222;
            case field_6172 -> class_9274.field_49221;
            case field_6166 -> class_9274.field_49220;
            default -> class_9274.field_49224;
        };
        return class_9285.method_57480()
            .method_57487(class_5134.field_23724, new class_1322(class_2960.method_60655("riftbound", "armor_" + slotName), armor, class_1322.class_1323.field_6328), group)
            .method_57487(class_5134.field_23725, new class_1322(class_2960.method_60655("riftbound", "toughness_" + slotName), toughness, class_1322.class_1323.field_6328), group)
            .method_57487(class_5134.field_23718, new class_1322(class_2960.method_60655("riftbound", "kb_" + slotName), 0.15, class_1322.class_1323.field_6328), group)
            .method_57486();
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 held = player.method_5998(hand);
        class_1799 equipped = player.method_6118(this.slot);
        if (equipped.method_7960()) {
            player.method_5673(this.slot, held.method_7972());
            held.method_7939(0);
            player.method_5783(class_3417.field_21866.comp_349(), 1.0f, 1.0f);
            return class_1269.field_5812;
        }
        return super.method_7836(level, player, hand);
    }
}