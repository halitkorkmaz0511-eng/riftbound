package com.riftbound.item;

import com.riftbound.ability.AbilityManager;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;

public class RiftWeaponItem extends class_1792 {
    private final int weaponType; // 1: Blade, 2: Scythe, 3: Staff

    public RiftWeaponItem(int weaponType, double attackDamage, double attackSpeed, class_1793 properties) {
        super(properties.method_57348(createAttributes(attackDamage, attackSpeed)));
        this.weaponType = weaponType;
    }

    private static class_9285 createAttributes(double baseDamage, double baseSpeed) {
        return class_9285.method_57480()
            .method_57487(class_5134.field_23721, new class_1322(class_2960.method_60655("riftbound", "weapon_damage"), baseDamage, class_1322.class_1323.field_6328), class_9274.field_49217)
            .method_57487(class_5134.field_23723, new class_1322(class_2960.method_60655("riftbound", "weapon_speed"), baseSpeed, class_1322.class_1323.field_6328), class_9274.field_49217)
            .method_57486();
    }

    @Override
    public boolean method_7873(class_1799 stack, class_1309 target, class_1309 attacker) {
        if (attacker.method_37908() instanceof class_3218 sLevel) {
            if (weaponType == 1) {
                // Rift Blade: Hızlı kesik ve ekstra büyü/boyut hasarı + Cyan parçacık
                sLevel.method_65096(AbilityManager.RIFT_CYAN, target.method_23317(), target.method_23318() + 1.0, target.method_23321(), 20, 0.3, 0.4, 0.3, 0.05);
                target.method_6092(new class_1293(class_1294.field_5909, 60, 1));
            } else if (weaponType == 2) {
                // Rift Scythe: Geniş alan (AoE) tırpan darbesi ve Can Çalma (Lifesteal)
                sLevel.method_65096(AbilityManager.RIFT_PURPLE, target.method_23317(), target.method_23318() + 1.0, target.method_23321(), 35, 1.2, 0.4, 1.2, 0.05);
                attacker.method_6025(2.5f);
                class_238 area = target.method_5829().method_1014(2.5);
                for (class_1309 nearby : sLevel.method_8390(class_1309.class, area, e -> e != attacker && e != target)) {
                    nearby.method_64419(sLevel.method_48963().method_48831(), 6.0f);
                }
            }
        }
        return true;
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (player.method_7357().method_7904(stack)) {
            return class_1269.field_5814;
        }

        if (level instanceof class_3218 sLevel) {
            if (weaponType == 1) {
                // Rift Blade Sağ Tık: Kısa mesafe gölge adımı (Blink)
                class_243 look = player.method_5720();
                player.method_18800(look.field_1352 * 1.5, 0.3, look.field_1350 * 1.5);
                player.field_6037 = true;
                sLevel.method_65096(AbilityManager.RIFT_CYAN, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 25, 0.4, 0.4, 0.4, 0.05);
                sLevel.method_8396(null, player.method_24515(), class_3417.field_14879, class_3419.field_15248, 0.8f, 1.5f);
                player.method_7357().method_62835(stack, 40);
            } else if (weaponType == 2) {
                // Rift Scythe Sağ Tık: Yakındaki düşmanları kendine doğru çeken boyutsal girdap
                sLevel.method_65096(AbilityManager.RIFT_PURPLE, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 50, 2.5, 0.5, 2.5, 0.08);
                sLevel.method_8396(null, player.method_24515(), class_3417.field_23116, class_3419.field_15248, 1.0f, 0.8f);
                class_238 pullBox = player.method_5829().method_1014(6.0);
                for (class_1309 e : sLevel.method_8390(class_1309.class, pullBox, ent -> ent != player)) {
                    class_243 pull = player.method_19538().method_1020(e.method_19538()).method_1029().method_1021(1.1);
                    e.method_18800(pull.field_1352, 0.35, pull.field_1350);
                    e.field_6037 = true;
                }
                player.method_7357().method_62835(stack, 80);
            } else if (weaponType == 3) {
                // Rift Staff Sağ Tık: İleriye doğru 12 blokluk boyutsal ışın (Rift Beam)
                class_243 start = player.method_33571();
                class_243 look = player.method_5720();
                sLevel.method_8396(null, player.method_24515(), class_3417.field_38830, class_3419.field_15248, 0.7f, 1.6f);
                for (int i = 1; i <= 14; i++) {
                    class_243 point = start.method_1019(look.method_1021(i));
                    sLevel.method_65096(AbilityManager.RIFT_CYAN, point.field_1352, point.field_1351, point.field_1350, 4, 0.1, 0.1, 0.1, 0.01);
                    sLevel.method_65096(AbilityManager.RIFT_PURPLE, point.field_1352, point.field_1351, point.field_1350, 4, 0.15, 0.15, 0.15, 0.02);
                    class_238 hitBox = new class_238(point.field_1352 - 1.0, point.field_1351 - 1.0, point.field_1350 - 1.0, point.field_1352 + 1.0, point.field_1351 + 1.0, point.field_1350 + 1.0);
                    List<class_1309> hits = sLevel.method_8390(class_1309.class, hitBox, e -> e != player);
                    for (class_1309 hit : hits) {
                        hit.method_64419(sLevel.method_48963().method_48802(player), 12.0f);
                    }
                }
                player.method_7357().method_62835(stack, 50);
            }
        }
        return class_1269.field_5812;
    }

    @Override
    public boolean method_7885(class_2680 state, class_1937 level, class_2338 pos, class_1657 player) {
        return !player.method_7337();
    }
}