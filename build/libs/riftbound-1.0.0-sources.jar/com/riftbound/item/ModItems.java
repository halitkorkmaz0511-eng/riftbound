package com.riftbound.item;

import com.riftbound.RiftboundMod;
import com.riftbound.ability.AbilityManager;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import java.util.function.Function;

public class ModItems {
    // 1. Çekirdek Eşya
    public static final class_1792 RIFT_CORE = register("rift_core", props -> new RiftCoreItem(props.method_7894(class_1814.field_8904).method_24359()));

    // 2. Özel Rift Silahları (Blade, Scythe, Staff)
    public static final class_1792 RIFT_BLADE = register("rift_blade", props -> new RiftWeaponItem(1, 9.0, -2.2, props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));
    public static final class_1792 RIFT_SCYTHE = register("rift_scythe", props -> new RiftWeaponItem(2, 12.0, -2.8, props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));
    public static final class_1792 RIFT_STAFF = register("rift_staff", props -> new RiftWeaponItem(3, 6.0, -2.4, props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));

    // 3. Rift Zırh Seti (Kask, Göğüslük, Pantolon, Bot)
    public static final class_1792 RIFT_HELMET = register("rift_helmet", props -> new RiftArmorItem(class_1304.field_6169, 4.0, 3.5, "head", props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));
    public static final class_1792 RIFT_CHESTPLATE = register("rift_chestplate", props -> new RiftArmorItem(class_1304.field_6174, 9.0, 3.5, "chest", props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));
    public static final class_1792 RIFT_LEGGINGS = register("rift_leggings", props -> new RiftArmorItem(class_1304.field_6172, 7.0, 3.5, "legs", props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));
    public static final class_1792 RIFT_BOOTS = register("rift_boots", props -> new RiftArmorItem(class_1304.field_6166, 4.0, 3.5, "feet", props.method_7894(class_1814.field_8904).method_24359().method_7889(1)));

    public static class_1792 register(String name, Function<class_1792.class_1793, class_1792> factory) {
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, RiftboundMod.id(name));
        class_1792.class_1793 props = new class_1792.class_1793().method_63686(key);
        class_1792 item = factory.apply(props);
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    public static void register() {
        RiftboundMod.LOGGER.info("Registering Riftbound Weapons & Armor Set...");
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40202).register(entries -> {
            entries.method_45421(RIFT_CORE);
            entries.method_45421(RIFT_BLADE);
            entries.method_45421(RIFT_SCYTHE);
            entries.method_45421(RIFT_STAFF);
            entries.method_45421(RIFT_HELMET);
            entries.method_45421(RIFT_CHESTPLATE);
            entries.method_45421(RIFT_LEGGINGS);
            entries.method_45421(RIFT_BOOTS);
        });

        // Tam Zırh Seti Giymiş Oyunculara Pasif Güçlendirme (Set Bonusu)
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;
            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_6118(class_1304.field_6169).method_31574(RIFT_HELMET) &&
                    player.method_6118(class_1304.field_6174).method_31574(RIFT_CHESTPLATE) &&
                    player.method_6118(class_1304.field_6172).method_31574(RIFT_LEGGINGS) &&
                    player.method_6118(class_1304.field_6166).method_31574(RIFT_BOOTS)) {
                    
                    player.method_6092(new class_1293(class_1294.field_5904, 40, 0, false, false, true));
                    player.method_6092(new class_1293(class_1294.field_5907, 40, 0, false, false, true));
                    player.method_6092(new class_1293(class_1294.field_5925, 220, 0, false, false, true));
                    if (player.method_37908() instanceof class_3218 sLevel) {
                        sLevel.method_65096(AbilityManager.RIFT_PURPLE, player.method_23317(), player.method_23318() + 0.5, player.method_23321(), 3, 0.3, 0.4, 0.3, 0.01);
                    }
                }
            }
        });
    }
}