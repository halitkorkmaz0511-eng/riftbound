package com.riftbound.item;

import com.riftbound.entity.ModEntities;
import com.riftbound.entity.boss.RiftSentinelEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class RiftCallerItem extends class_1792 {
    public RiftCallerItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        if (!level.field_9236 && level instanceof class_3218 serverLevel) {
            class_2338 pos = context.method_8037().method_10084();
            RiftSentinelEntity sentinel = new RiftSentinelEntity(ModEntities.RIFT_SENTINEL, serverLevel);
            sentinel.method_5808(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, context.method_8044(), 0.0f);
            sentinel.triggerSpawnSequence();
            serverLevel.method_8649(sentinel);

            serverLevel.method_8396(null, pos, class_3417.field_14981, class_3419.field_15251, 1.2f, 0.75f);
            if (context.method_8036() != null) {
                context.method_8036().method_7353(class_2561.method_43470("§5The dimensional boundary shatters... The Rift Sentinel awakens!"), false);
                context.method_8041().method_57008(1, context.method_8036());
            }
            return class_1269.field_5812;
        }
        return class_1269.field_5812;
    }
}
