package com.riftbound.item;

import com.riftbound.ability.AbilityManager;
import com.riftbound.network.RiftboundPayloads;
import com.riftbound.progression.PlayerRiftData;
import com.riftbound.progression.RiftProgressionState;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class RiftCoreItem extends class_1792 {
    public RiftCoreItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
            RiftProgressionState state = RiftProgressionState.getServerState(serverPlayer.field_13995);
            PlayerRiftData data = state.getPlayerData(serverPlayer.method_5667());

            if (data.unlockedTier >= 3) {
                serverPlayer.method_7353(class_2561.method_43470("§dYou have already mastered all 3 Riftbound abilities!"), true);
                return class_1269.field_5814;
            }

            data.unlockedTier++;
            state.setDirty();
            RiftboundPayloads.syncToClient(serverPlayer, data);

            String unlockedName = switch (data.unlockedTier) {
                case 1 -> "§bRift Dash §7(Press [R])";
                case 2 -> "§dVoid Pulse §7(Press [G])";
                case 3 -> "§5Rift Shield §7(Press [V])";
                default -> "Unknown";
            };

            serverPlayer.method_64398(class_2561.method_43470("§5✦ [RIFT AWAKENED] §fYou absorbed the Rift Core and unlocked: " + unlockedName));
            class_3218 sLevel = serverPlayer.method_51469();
            sLevel.method_8396(null, serverPlayer.method_24515(), class_3417.field_15195, class_3419.field_15248, 1.0f, 1.1f);
            sLevel.method_65096(class_2398.field_11207, serverPlayer.method_23317(), serverPlayer.method_23318() + 1.0, serverPlayer.method_23321(), 40, 0.5, 0.8, 0.5, 0.15);
            sLevel.method_65096(AbilityManager.RIFT_CYAN, serverPlayer.method_23317(), serverPlayer.method_23318() + 1.0, serverPlayer.method_23321(), 30, 0.5, 0.8, 0.5, 0.05);

            stack.method_57008(1, serverPlayer);
            return class_1269.field_5812;
        }
        return class_1269.field_5812;
    }
}
