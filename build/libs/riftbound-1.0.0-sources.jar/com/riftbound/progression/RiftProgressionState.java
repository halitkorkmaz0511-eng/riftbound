package com.riftbound.progression;

import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RiftProgressionState {
    private static final RiftProgressionState INSTANCE = new RiftProgressionState();
    private final Map<UUID, PlayerRiftData> playerDataMap = new HashMap<>();

    public static RiftProgressionState getServerState(MinecraftServer server) {
        return INSTANCE;
    }

    public static RiftProgressionState getServerState(class_3218 level) {
        return INSTANCE;
    }

    public PlayerRiftData getPlayerData(UUID uuid) {
        return playerDataMap.computeIfAbsent(uuid, k -> new PlayerRiftData());
    }

    public PlayerRiftData getPlayerData(class_3222 player) {
        return getPlayerData(player.method_5667());
    }

    public void setDirty() {
        // Güvenli bellek içi kayıt
    }
}