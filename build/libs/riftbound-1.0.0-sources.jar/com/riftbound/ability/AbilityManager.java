package com.riftbound.ability;

import com.riftbound.network.RiftboundPayloads;
import com.riftbound.progression.PlayerRiftData;
import com.riftbound.progression.RiftProgressionState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.List;

public class AbilityManager {
    public static final class_2390 RIFT_CYAN = new class_2390(0x00E5FF, 1.2f);
    public static final class_2390 RIFT_PURPLE = new class_2390(0xB219FF, 1.2f);

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            RiftProgressionState state = RiftProgressionState.getServerState(server);
            for (class_3222 player : server.method_3760().method_14571()) {
                PlayerRiftData data = state.getPlayerData(player.method_5667());
                boolean changed = false;

                if (data.getDashCooldown() > 0) { data.setDashCooldown(data.getDashCooldown() - 1); changed = true; }
                if (data.getPulseCooldown() > 0) { data.setPulseCooldown(data.getPulseCooldown() - 1); changed = true; }
                if (data.getShieldCooldown() > 0) { data.setShieldCooldown(data.getShieldCooldown() - 1); changed = true; }
                if (data.getShieldActiveTicks() > 0) {
                    data.setShieldActiveTicks(data.getShieldActiveTicks() - 1);
                    if (player.method_37908() instanceof class_3218 sLevel && server.method_3780() % 4 == 0) {
                        sLevel.method_65096(RIFT_CYAN, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 6, 0.5, 0.6, 0.5, 0.02);
                    }
                    changed = true;
                }

                if (changed && server.method_3780() % 5 == 0) {
                    RiftboundPayloads.syncToClient(player, data);
                }
            }
        });
    }

    public static void useAbility(class_3222 player, int abilityId) {
        if (!(player.method_37908() instanceof class_3218 sLevel)) return;
        RiftProgressionState state = RiftProgressionState.getServerState(player.field_13995);
        PlayerRiftData data = state.getPlayerData(player.method_5667());

        if (data.getUnlockedTier() < abilityId) return;

        if (abilityId == 1 && data.getDashCooldown() <= 0) {
            // Yetenek 1: Rift Dash (İleri Atılma)
            class_243 look = player.method_5720();
            player.method_18800(look.field_1352 * 1.8, Math.max(look.field_1351 * 1.2, 0.35), look.field_1350 * 1.8);
            player.field_6037 = true;
            sLevel.method_65096(RIFT_CYAN, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 35, 0.4, 0.5, 0.4, 0.08);
            sLevel.method_8396(null, player.method_24515(), class_3417.field_14879, class_3419.field_15248, 1.0f, 1.2f);
            data.setDashCooldown(60); // 3 saniye
            RiftboundPayloads.syncToClient(player, data);
        } 
        else if (abilityId == 2 && data.getPulseCooldown() <= 0) {
            // Yetenek 2: Rift Pulse (Alan Hasarı ve Savurma)
            sLevel.method_65096(RIFT_PURPLE, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 60, 2.0, 0.5, 2.0, 0.1);
            sLevel.method_8396(null, player.method_24515(), class_3417.field_38830, class_3419.field_15248, 0.8f, 1.4f);
            class_238 box = player.method_5829().method_1014(5.0);
            List<class_1309> targets = sLevel.method_8390(class_1309.class, box, e -> e != player);
            for (class_1309 target : targets) {
                target.method_64419(sLevel.method_48963().method_48802(player), 10.0f);
                class_243 push = target.method_19538().method_1020(player.method_19538()).method_1029().method_1021(1.4);
                target.method_18800(push.field_1352, 0.45, push.field_1350);
                target.field_6037 = true;
            }
            data.setPulseCooldown(120); // 6 saniye
            RiftboundPayloads.syncToClient(player, data);
        } 
        else if (abilityId == 3 && data.getShieldCooldown() <= 0) {
            // Yetenek 3: Rift Shield (Koruma Kalkanı)
            player.method_6092(new class_1293(class_1294.field_5907, 100, 2));
            player.method_6092(new class_1293(class_1294.field_5898, 100, 1));
            sLevel.method_65096(RIFT_CYAN, player.method_23317(), player.method_23318() + 1.0, player.method_23321(), 50, 0.7, 0.9, 0.7, 0.05);
            sLevel.method_8396(null, player.method_24515(), class_3417.field_14703, class_3419.field_15248, 1.0f, 1.3f);
            data.setShieldActiveTicks(100); // 5 saniye aktif
            data.setShieldCooldown(240); // 12 saniye bekleme
            RiftboundPayloads.syncToClient(player, data);
        }
    }
}