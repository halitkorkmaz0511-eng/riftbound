package com.riftbound;

import com.riftbound.ability.AbilityManager;
import com.riftbound.entity.ModEntities;
import com.riftbound.item.ModItems;
import com.riftbound.network.RiftboundPayloads;
import com.riftbound.world.structure.ModStructures;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RiftboundMod implements ModInitializer {
    public static final String MOD_ID = "riftbound";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        com.riftbound.horror.HorrorDirector.init();
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            handler.field_14140.method_64398(net.minecraft.class_2561.method_43470("\u00A7d[Riftbound] \u00A7bMod rehberini acmak icin Z tusuna basiniz."));
        });
        com.riftbound.block.ModBlocks.register();
        com.riftbound.block.ModBlockEntities.register();
        com.riftbound.command.RiftCommands.register();
        LOGGER.info("Initializing Riftbound Mod");
        ModItems.register();
        ModEntities.register();
        RiftboundPayloads.register();
        AbilityManager.register();
        ModStructures.register();
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}